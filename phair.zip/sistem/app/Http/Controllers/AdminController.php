<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Koordinatjarak;
use App\Koordinat;
use DB;
use Auth;
use Session;
use Image;
use Input;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }


    
    public function index(Request $request)
    {
        $jarak = DB::select('select * from tb_parameter_input');
        foreach ($jarak as $key => $value) {
            $nilai_p = $value->nilai_p;
            $time = $value->time_series;
        }

        // Fungsi menghitung jarak haversine
        DB::select("TRUNCATE table tb_koordinat_jarak");
        DB::select("TRUNCATE table tb_notifikasi_bahaya");

        function haversine_distance($lat1, $lon1, $lat2, $lon2) {
        $earth_radius = 6371000.0; // Radius bumi dalam meter

        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);

        $a = sin($dLat / 2.0) * sin($dLat / 2.0) +
        cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
        sin($dLon / 2.0) * sin($dLon / 2.0);

        $c = 2.0 * atan2(sqrt($a), sqrt(1.0 - $a));

        $distance = $earth_radius * $c;

    return round($distance, 0); // Bulatkan ke bilangan bulat tanpa koma

}

    // Koordinat titik referensi
$lat_titik_1 = -6.889945;
$lon_titik_1 = 109.403348;

$lat_titik_2 = -6.89024;
$lon_titik_2 = 109.40343;

$lat_titik_3 = -6.89057;
$lon_titik_3 = 109.40316;

    // Daftar koordinat yang telah dihasilkan
// $koordinat_daftar = Koordinat::all();
$koordinat_daftar = [
    [-6.88994, 109.40334],// Pak Tosim
    [-6.88997, 109.40322],
    [-6.88987, 109.40304],
    [-6.88992, 109.40340],//Pengujian, Mas Imron
    [-6.89057, 109.40316],//Mba yang
    [-6.89024, 109.40343],//Mas Ali
    [-6.88985, 109.40290],
    [-6.89045, 109.40375],
    [-6.89015, 109.40305],
    [-6.89080, 109.40400],
    [-6.89030, 109.40260],
    [-6.89060, 109.40335],
    [-6.89025, 109.40345],
    [-6.89075, 109.40385],
    [-6.89095, 109.40320],
    [-6.89010, 109.40390],
    [-6.89055, 109.40315],
    [-6.89040, 109.40360],
    [-6.89070, 109.40410],
    [-6.89000, 109.40275],
    [-6.89090, 109.40405],
    [-6.89035, 109.40330],
    [-6.89085, 109.40275],
    [-6.89005, 109.40295],
    [-6.89025, 109.40375],
    [-6.89065, 109.40345],
    [-6.89015, 109.40270],
    [-6.89055, 109.40385],
    [-6.89045, 109.40325],
    [-6.89085, 109.40355],
    [-6.89010, 109.40355],
    [-6.89040, 109.40310],
    [-6.89070, 109.40390],
    [-6.89030, 109.40355],
    [-6.89090, 109.40375],
    [-6.89020, 109.40395],
    [-6.89060, 109.40375],
    [-6.89025, 109.40325],
    [-6.89075, 109.40315],
    [-6.89000, 109.40365],
    [-6.89050, 109.40385],
    [-6.89080, 109.40330],
    [-6.89035, 109.40385],
    [-6.89095, 109.40345],
    [-6.89010, 109.40325],
    [-6.89040, 109.40370],
    [-6.89070, 109.40340],
    [-6.89030, 109.40375],
    [-6.89090, 109.40305],
    [-6.89020, 109.40365],
    [-6.89060, 109.40305],
    [-6.89025, 109.40385],
    [-6.89075, 109.40325],
    [-6.89001, 109.40369],

];


foreach ($koordinat_daftar as $koordinat) {
    $lat = $koordinat[0];
    $lon = $koordinat[1];

    $jarak_titik_1 = haversine_distance($lat_titik_1, $lon_titik_1, $lat, $lon);
    $jarak_titik_2 = haversine_distance($lat_titik_2, $lon_titik_2, $lat, $lon);
    $jarak_titik_3 = haversine_distance($lat_titik_3, $lon_titik_3, $lat, $lon);

        // Simpan hasil perhitungan ke dalam tabel (asumsi model Input ada)
    Koordinatjarak::create([
        'nilai_p' => "$nilai_p",
        'koordinat' => "$lat, $lon",
        'jarak_titik_1' => $jarak_titik_1,
        'jarak_titik_2' => $jarak_titik_2,
        'jarak_titik_3' => $jarak_titik_3,
    ]);
}

$get_ph_air = DB::select('SELECT titik, ph
    FROM tb_phair AS t1
    WHERE created_at = (
        SELECT MAX(created_at)
        FROM tb_phair AS t2
        WHERE t1.titik = t2.titik
        )
    ');
$ph_titik_1 = null;
$ph_titik_2 = null;
$ph_titik_3 = null;

foreach ($get_ph_air as $row) {
    $titik = $row->titik;
    $ph = $row->ph;

    if ($titik === 'titik_1') {
        $ph_titik_1 = $ph;
    } elseif ($titik === 'titik_2') {
        $ph_titik_2 = $ph;
    } elseif ($titik === 'titik_3') {
        $ph_titik_3 = $ph;
    }
}
// Memastikan ada hasil yang ditemukan
if (!empty($get_ph_air)) {
    // Mengisi variabel dengan data yang diambil dari hasil query
    $ph_titik_1 = $get_ph_air[0]->ph;
    $ph_titik_2 = $get_ph_air[1]->ph;
    $ph_titik_3 = $get_ph_air[2]->ph;
} else {
    echo "Tidak ada data yang ditemukan.";
}

// Hitung estimasi PH Air
$hitung_estimasi_ph_air = DB::select("
    SELECT koordinat, jarak_titik_1, jarak_titik_2, jarak_titik_3, created_at as waktu, nilai_p,
    ROUND(
        COALESCE((
            COALESCE(SUM(1/POW(jarak_titik_1, $nilai_p)), 0) * $ph_titik_1 +
            COALESCE(SUM(1/POW(jarak_titik_2, $nilai_p)), 0) * $ph_titik_2 +
            COALESCE(SUM(1/POW(jarak_titik_3, $nilai_p)), 0) * $ph_titik_3
        ) /
        (
            COALESCE(SUM(1/POW(jarak_titik_1, $nilai_p)), 0) +
            COALESCE(SUM(1/POW(jarak_titik_2, $nilai_p)), 0) +
            COALESCE(SUM(1/POW(jarak_titik_3, $nilai_p)), 0)
        ), 0), 2) as estimasi_phair
    FROM tb_koordinat_jarak
    GROUP BY id");

foreach ($hitung_estimasi_ph_air as $data) {
    $koordinat = $data->koordinat;
    $ph = $data->estimasi_phair;
    $waktu = $data->waktu;


    if ($ph < 6.5 || $ph > 8.5) {
        // Simpan data ke dalam tb_notifikasi_bahaya
        DB::table('tb_notifikasi_bahaya')->insert([
            'koordinat' => $koordinat,
            'ph' => $ph,
            
            'created_at' => $waktu,
        ]);
    }
}

DB::select("TRUNCATE table tb_hasil_idw");
foreach ($hitung_estimasi_ph_air as $data) {
    $koordinat = $data->koordinat;
    $ph = $data->estimasi_phair;
    $nilai_p = $data->nilai_p;
    $jarak_titik_1 = $data->jarak_titik_1;
    $jarak_titik_2 = $data->jarak_titik_2;
    $jarak_titik_3 = $data->jarak_titik_3;
    $waktu = $data->waktu;
        // Simpan data
        DB::table('tb_hasil_idw')->insert([
            'koordinat' => $koordinat,
            'ph' => $ph,
            'nilai_p' => $nilai_p,
            'jarak_titik_1' => $jarak_titik_1,
            'jarak_titik_2' => $jarak_titik_2,
            'jarak_titik_3' => $jarak_titik_3,
            'created_at' => $waktu,
        ]);
}

$notifikasi = DB::select('select * from tb_notifikasi_bahaya order by created_at DESC');

$output_koordinat = array_column($hitung_estimasi_ph_air, 'koordinat');
$output_phair = array_column($hitung_estimasi_ph_air, 'estimasi_phair');

//Rumus Interval : WHERE DATE_SUB(NOW(), INTERVAL 8 HOUR)
$data = DB::select("select DATE_FORMAT(created_at, '%H:%i') as waktu, AVG(ph) as ph 
    FROM tb_phair 
    GROUP By (4 * HOUR(created_at) + FLOOR( MINUTE(created_at) / '".$time."')) ORDER BY created_at DESC");
$ph      = array_column($data, 'ph');
$waktu      = array_column($data, 'waktu');

$titik1 = DB::select("select DATE_FORMAT(created_at, '%H:%i') as waktu, AVG(ph) as ph 
    FROM tb_phair WHERE titik = '1'
    GROUP By (4 * HOUR(created_at) + FLOOR( MINUTE(created_at) / '".$time."')) ORDER BY created_at DESC");
$ph1      = array_column($titik1, 'ph');
$waktu1      = array_column($titik1, 'waktu');

$titik2 = DB::select("select DATE_FORMAT(created_at, '%H:%i') as waktu, AVG(ph) as ph 
    FROM tb_phair WHERE titik = '2'
    GROUP By (4 * HOUR(created_at) + FLOOR( MINUTE(created_at) / '".$time."')) ORDER BY created_at DESC");
$ph2      = array_column($titik2, 'ph');
$waktu2      = array_column($titik2, 'waktu');

$titik3 = DB::select("select DATE_FORMAT(created_at, '%H:%i') as waktu, AVG(ph) as ph 
    FROM tb_phair WHERE titik = '3'
    GROUP By (4 * HOUR(created_at) + FLOOR( MINUTE(created_at) / '".$time."')) ORDER BY created_at DESC");
$ph3       = array_column($titik3, 'ph');
$waktu3      = array_column($titik3, 'waktu');

return view('home', compact('data','time','nilai_p','notifikasi'))
->with('ph',json_encode($ph,JSON_NUMERIC_CHECK))
->with('waktu',json_encode($waktu,JSON_NUMERIC_CHECK))
->with('ph1',json_encode($ph1,JSON_NUMERIC_CHECK))
->with('waktu1',json_encode($waktu1,JSON_NUMERIC_CHECK))
->with('ph2',json_encode($ph2,JSON_NUMERIC_CHECK))
->with('waktu2',json_encode($waktu2,JSON_NUMERIC_CHECK))
->with('ph3',json_encode($ph3,JSON_NUMERIC_CHECK))
->with('waktu3',json_encode($waktu3,JSON_NUMERIC_CHECK))
->with('output_koordinat',json_encode($output_koordinat,JSON_NUMERIC_CHECK))
->with('output_phair',json_encode($output_phair,JSON_NUMERIC_CHECK));
}




public function dataphair()
{
 $data = DB::select('select *, DATE_FORMAT(tb_phair.created_at, "%H:%I:%S || %d/%m/%Y") as waktu from tb_phair Order By created_at DESC');
 return view('admin.data-phair',compact('data'));
}

public function datanotifikasi()
{
 $data = DB::select('select * from tb_notifikasi_bahaya order by created_at DESC');
 return view('admin.data-notifikasi',compact('data'));
}

public function datalokasipengujian()
{
 $data = DB::select('select * from tb_koordinat_jarak');
 return view('admin.data-lokasi-pengujian',compact('data'));
}

public function simulasiaman(Request $request)
{
    date_default_timezone_set('Asia/Jakarta');
    $amonia = DB::select('select *, DATE_FORMAT(tb_phair.created_at, "%H:%I:%S || %d/%m/%Y") as waktu from tb_phair Order By created_at DESC');

    $titik  = mt_rand(1, 3);
    $adc1   = mt_rand(80, 125);
    $adc2   = mt_rand(80, 180);
    $vrl1   = mt_rand(200000000, 600000000)/ 1000000000;
    $vrl2   = mt_rand(500000000, 800000000)/ 1000000000;
    $rs     = mt_rand(80000, 300000);
    $ph    = mt_rand(100000000, 450000000)/ 1000000000;

    $data = new Amonia;
    $data->rl               = 2000;
    $data->ro               = 108251;
    $data->vref             = 5;
    $data->vadc             = 1024;
    $data->resolusi         = 0.00488281;
    $data->adc1             = $adc1;
    $data->adc2             = $adc2;
    $data->vrl1             = $vrl1;
    $data->vrl2             = $vrl2;
    $data->rs               = $rs;
    $data->ph              = $ph;
    $data->titik            = $titik;
    $data->save();

    return view('admin.data-amonia-aman',compact('data','amonia'));
}

public function simulasiwaspada(Request $request)
{
    date_default_timezone_set('Asia/Jakarta');
    $amonia = DB::select('select *, DATE_FORMAT(tb_phair.created_at, "%H:%I:%S || %d/%m/%Y") as waktu from tb_phair Order By created_at DESC');

    $titik  = mt_rand(1, 3);
    $adc1   = mt_rand(80, 125);
    $adc2   = mt_rand(80, 180);
    $vrl1   = mt_rand(200000000, 600000000)/ 1000000000;
    $vrl2   = mt_rand(500000000, 800000000)/ 1000000000;
    $rs     = mt_rand(80000, 300000);
    $ph    = mt_rand(500000000, 1900000000)/ 1000000000;

    $data = new Amonia;
    $data->rl               = 2000;
    $data->ro               = 108251;
    $data->vref             = 5;
    $data->vadc             = 1024;
    $data->resolusi         = 0.00488281;
    $data->adc1             = $adc1;
    $data->adc2             = $adc2;
    $data->vrl1             = $vrl1;
    $data->vrl2             = $vrl2;
    $data->rs               = $rs;
    $data->ph              = $ph;
    $data->titik            = $titik;
    $data->save();

    return view('admin.data-amonia-waspada',compact('data','amonia'));
}

public function simulasibahaya(Request $request)
{
    date_default_timezone_set('Asia/Jakarta');
    $amonia = DB::select('select *, DATE_FORMAT(tb_phair.created_at, "%H:%I:%S || %d/%m/%Y") as waktu from tb_phair Order By created_at DESC');

    $titik  = mt_rand(1, 3);
    $adc1   = mt_rand(80, 125);
    $adc2   = mt_rand(80, 180);
    $vrl1   = mt_rand(200000000, 600000000)/ 1000000000;
    $vrl2   = mt_rand(500000000, 800000000)/ 1000000000;
    $rs     = mt_rand(80000, 300000);
    $ph    = mt_rand(200000000, 300000000)/ 10000000;

    $data = new Amonia;
    $data->rl               = 2000;
    $data->ro               = 108251;
    $data->vref             = 5;
    $data->vadc             = 1024;
    $data->resolusi         = 0.00488281;
    $data->adc1             = $adc1;
    $data->adc2             = $adc2;
    $data->vrl1             = $vrl1;
    $data->vrl2             = $vrl2;
    $data->rs               = $rs;
    $data->ph              = $ph;
    $data->titik            = $titik;
    $data->save();

    return view('admin.data-amonia-bahaya',compact('data','amonia'));
}

public function bahayaamonia()
{
 $data = DB::select('select * from tb_bahaya_amonia');
 return view('admin.bahaya-amonia',compact('data'));
}

public function user()
{
 $data = DB::select('select * from users');
 return view('admin.user',compact('data'));
}

public function simpanuser(Request $request)
{

    $this->validate($request, [
      'name' => 'required|max:255',
      'username' => 'required|max:255|unique:users',
      'email' => 'required|email|max:255|unique:users',
      'password' => 'required|min:6|confirmed',

  ]);
    error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
    $acak=rand(11111,99999);
    $id_t = str_shuffle($acak);

    if (Input::hasFile('foto'))
    {
        $file = array('foto' => Input::file('foto'));
        if (Input::file('foto')->isValid()) 
        {
            $destinationPath = 'images/presensi';
                $extension = Input::file('foto')->getClientOriginalExtension(); // getting image extension
                $fileName = rand(11111,99999).'.'.$extension; // renaming image
                $green = Input::file('foto');
                $img = Image::make($green)->resize('200','200')->save('images/sistem/'.$fileName);
                $input['foto'] =$destinationPath. '/'.$fileName;  

                $user = new User();
                $user->foto = $input['foto'];
                $user->name = $request->name;
                $user->username = $request->username;
                $user->email = $request->email;
                $user->password = bcrypt($request->password);
                $user->lihat_password = $request->password;
                
            } else {
                $user = new User();
                $user->name = $request->name;
                $user->username = $request->username;
                $user->email = $request->email;
                $user->password = bcrypt($request->password);
                $user->lihat_password = $request->password;
            }   

        }

        $user->save();
        Session::flash('sukses', 'data berhasil di simpan');
        return back();
    }

    public function updateuser(Request $request, $id)
    {

        $nama = $_POST['name'];
        $username = $request->username;
        $email = $_POST['email'];
        $password = $_POST['password'];

        if (empty($_POST['password'])) {
            $user = User::find($id);
            $user->name = $nama;
            $user->username = $username;
            $user->email = $email;
            $user->save();
        } else {
            $user = User::find($id);
            $user->name = $nama;
            $user->username = $username;
            $user->email = $email;
            $user->lihat_password = $password;
            $user->password = bcrypt($password);
            $user->save();
        }

        Session::flash('sukses', 'data berhasil di edit');
        return back();
    }

    public function hapususer($id)
    {
        $user = User::find($id);
        $user->delete();
        Session::flash('sukses', 'data berhasil di hapus');
        return back();
    }

    public function parameterinput()
    {
    	$data = DB::select('select * from tb_parameter_input');
        return view('admin.parameter-input',compact('data'));
    }

        public function updateinputan(Request $request)
    {
        DB::update("UPDATE tb_parameter_input SET nilai_p =  '".$request->nilai_p."', time_series =  '".$request->timeseries."'");

        Session::flash('sukses', 'data berhasil di simpan');
        return back();
    }

    public function updateparameterinput(Request $request)
    {
        DB::update("UPDATE tb_parameter_input SET nilai_p =  '".$request->nilai_p."', time_series =  '".$request->timeseries."'");

        Session::flash('sukses', 'data berhasil di simpan');
        return back();
    }

    public function edukasi()
    {
        return view('admin.edukasi');
    }
}
