<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Koordinatjarak;
use App\Koordinat;
use DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
        public function index(Request $request)
    {
        $jarak = DB::select('select * from tb_parameter_input');
        foreach ($jarak as $key => $value) {
            $nilai_p = $value->nilai_p;
            $time = $value->time_series;
        }

        // Fungsi menghitung jarak haversine
        DB::select("TRUNCATE table tb_koordinat_jarak");
        DB::select("TRUNCATE table tb_notifikasi_bahaya");

        function haversine_distance($lat1, $lon1, $lat2, $lon2) {
        $earth_radius = 6371000.0; // Radius bumi dalam meter

        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);

        $a = sin($dLat / 2.0) * sin($dLat / 2.0) +
        cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
        sin($dLon / 2.0) * sin($dLon / 2.0);

        $c = 2.0 * atan2(sqrt($a), sqrt(1.0 - $a));

        $distance = $earth_radius * $c;

    return round($distance, 0); // Bulatkan ke bilangan bulat tanpa koma

}

    // Koordinat titik referensi
$lat_titik_1 = -6.889945;
$lon_titik_1 = 109.403348;

$lat_titik_2 = -6.89024;
$lon_titik_2 = 109.40343;

$lat_titik_3 = -6.89057;
$lon_titik_3 = 109.40316;

    // Daftar koordinat yang telah dihasilkan
$koordinat_daftar = [
    [-6.88994, 109.40334],// Pak Tosim
    [-6.88997, 109.40322],
    [-6.88987, 109.40304],
    [-6.88992, 109.40340],//Pengujian, Mas Imron
    [-6.89057, 109.40316],//Mba yang
    [-6.89024, 109.40343],//Mas Ali
    [-6.88985, 109.40290],
    [-6.89045, 109.40375],
    [-6.89015, 109.40305],
    [-6.89080, 109.40400],
    [-6.89030, 109.40260],
    [-6.89060, 109.40335],
    [-6.89025, 109.40345],
    [-6.89075, 109.40385],
    [-6.89095, 109.40320],
    [-6.89010, 109.40390],
    [-6.89055, 109.40315],
    [-6.89040, 109.40360],
    [-6.89070, 109.40410],
    [-6.89000, 109.40275],
    [-6.89090, 109.40405],
    [-6.89035, 109.40330],
    [-6.89085, 109.40275],
    [-6.89005, 109.40295],
    [-6.89025, 109.40375],
    [-6.89065, 109.40345],
    [-6.89015, 109.40270],
    [-6.89055, 109.40385],
    [-6.89045, 109.40325],
    [-6.89085, 109.40355],
    [-6.89010, 109.40355],
    [-6.89040, 109.40310],
    [-6.89070, 109.40390],
    [-6.89030, 109.40355],
    [-6.89090, 109.40375],
    [-6.89020, 109.40395],
    [-6.89060, 109.40375],
    [-6.89025, 109.40325],
    [-6.89075, 109.40315],
    [-6.89000, 109.40365],
    [-6.89050, 109.40385],
    [-6.89080, 109.40330],
    [-6.89035, 109.40385],
    [-6.89095, 109.40345],
    [-6.89010, 109.40325],
    [-6.89040, 109.40370],
    [-6.89070, 109.40340],
    [-6.89030, 109.40375],
    [-6.89090, 109.40305],
    [-6.89020, 109.40365],
    [-6.89060, 109.40305],
    [-6.89025, 109.40385],
    [-6.89075, 109.40325],
    [-6.89001, 109.40369],

];


foreach ($koordinat_daftar as $koordinat) {
    $lat = $koordinat[0];
    $lon = $koordinat[1];

    $jarak_titik_1 = haversine_distance($lat_titik_1, $lon_titik_1, $lat, $lon);
    $jarak_titik_2 = haversine_distance($lat_titik_2, $lon_titik_2, $lat, $lon);
    $jarak_titik_3 = haversine_distance($lat_titik_3, $lon_titik_3, $lat, $lon);

        // Simpan hasil perhitungan ke dalam tabel (asumsi model Input ada)
    Koordinat::create([
        'nilai_p' => "$nilai_p",
        'koordinat' => "$lat, $lon",
        'jarak_titik_1' => $jarak_titik_1,
        'jarak_titik_2' => $jarak_titik_2,
        'jarak_titik_3' => $jarak_titik_3,
    ]);
}

$get_ph_air = DB::select('SELECT titik, ph
    FROM tb_phair AS t1
    WHERE created_at = (
        SELECT MAX(created_at)
        FROM tb_phair AS t2
        WHERE t1.titik = t2.titik
        )
    ');
$ph_titik_1 = null;
$ph_titik_2 = null;
$ph_titik_3 = null;

foreach ($get_ph_air as $row) {
    $titik = $row->titik;
    $ph = $row->ph;

    if ($titik === 'titik_1') {
        $ph_titik_1 = $ph;
    } elseif ($titik === 'titik_2') {
        $ph_titik_2 = $ph;
    } elseif ($titik === 'titik_3') {
        $ph_titik_3 = $ph;
    }
}
// Memastikan ada hasil yang ditemukan
if (!empty($get_ph_air)) {
    // Mengisi variabel dengan data yang diambil dari hasil query
    $ph_titik_1 = $get_ph_air[0]->ph;
    $ph_titik_2 = $get_ph_air[1]->ph;
    $ph_titik_3 = $get_ph_air[2]->ph;
} else {
    echo "Tidak ada data yang ditemukan.";
}

// Hitung estimasi PH Air
$hitung_estimasi_ph_air = DB::select("
    SELECT koordinat, created_at as waktu,
    ROUND(
        COALESCE((
            COALESCE(SUM(1/POW(jarak_titik_1, $nilai_p)), 0) * $ph_titik_1 +
            COALESCE(SUM(1/POW(jarak_titik_2, $nilai_p)), 0) * $ph_titik_2 +
            COALESCE(SUM(1/POW(jarak_titik_3, $nilai_p)), 0) * $ph_titik_3
        ) /
        (
            COALESCE(SUM(1/POW(jarak_titik_1, $nilai_p)), 0) +
            COALESCE(SUM(1/POW(jarak_titik_2, $nilai_p)), 0) +
            COALESCE(SUM(1/POW(jarak_titik_3, $nilai_p)), 0)
        ), 0), 2) as estimasi_phair
    FROM tb_koordinat_jarak
    GROUP BY id");

foreach ($hitung_estimasi_ph_air as $data) {
    $koordinat = $data->koordinat;
    $ph = $data->estimasi_phair;
    $waktu = $data->waktu;

    if ($ph < 6.5 || $ph > 8.5) {
        // Simpan data ke dalam tb_notifikasi_bahaya
        DB::table('tb_notifikasi_bahaya')->insert([
            'koordinat' => $koordinat,
            'ph' => $ph,
            'waktu' => $waktu,
        ]);
    }
}

$notifikasi = DB::select('select * from tb_notifikasi_bahaya order by created_at DESC');

$output_koordinat = array_column($hitung_estimasi_ph_air, 'koordinat');
$output_phair = array_column($hitung_estimasi_ph_air, 'estimasi_phair');

//Rumus Interval : WHERE DATE_SUB(NOW(), INTERVAL 8 HOUR)
$data = DB::select("select DATE_FORMAT(created_at, '%H:%i') as waktu, AVG(ph) as ph 
    FROM tb_phair 
    GROUP By (4 * HOUR(created_at) + FLOOR( MINUTE(created_at) / '".$time."')) ORDER BY created_at DESC");
$ph      = array_column($data, 'ph');
$waktu      = array_column($data, 'waktu');

$titik1 = DB::select("select DATE_FORMAT(created_at, '%H:%i') as waktu, AVG(ph) as ph 
    FROM tb_phair WHERE titik = '1'
    GROUP By (4 * HOUR(created_at) + FLOOR( MINUTE(created_at) / '".$time."')) ORDER BY created_at DESC");
$ph1      = array_column($titik1, 'ph');
$waktu1      = array_column($titik1, 'waktu');

$titik2 = DB::select("select DATE_FORMAT(created_at, '%H:%i') as waktu, AVG(ph) as ph 
    FROM tb_phair WHERE titik = '2'
    GROUP By (4 * HOUR(created_at) + FLOOR( MINUTE(created_at) / '".$time."')) ORDER BY created_at DESC");
$ph2      = array_column($titik2, 'ph');
$waktu2      = array_column($titik2, 'waktu');

$titik3 = DB::select("select DATE_FORMAT(created_at, '%H:%i') as waktu, AVG(ph) as ph 
    FROM tb_phair WHERE titik = '3'
    GROUP By (4 * HOUR(created_at) + FLOOR( MINUTE(created_at) / '".$time."')) ORDER BY created_at DESC");
$ph3       = array_column($titik3, 'ph');
$waktu3      = array_column($titik3, 'waktu');

return view('guest', compact('data','time','nilai_p','notifikasi'))
->with('ph',json_encode($ph,JSON_NUMERIC_CHECK))
->with('waktu',json_encode($waktu,JSON_NUMERIC_CHECK))
->with('ph1',json_encode($ph1,JSON_NUMERIC_CHECK))
->with('waktu1',json_encode($waktu1,JSON_NUMERIC_CHECK))
->with('ph2',json_encode($ph2,JSON_NUMERIC_CHECK))
->with('waktu2',json_encode($waktu2,JSON_NUMERIC_CHECK))
->with('ph3',json_encode($ph3,JSON_NUMERIC_CHECK))
->with('waktu3',json_encode($waktu3,JSON_NUMERIC_CHECK))
->with('output_koordinat',json_encode($output_koordinat,JSON_NUMERIC_CHECK))
->with('output_phair',json_encode($output_phair,JSON_NUMERIC_CHECK));
}
}
