<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use App\User;
use App\Menu;
use DB;
use Form;
use Input;
use Excel;
use Session;
use Redirect;

class MenuController extends Controller
{
    public function menu()
    {
        $menu = Menu::orderBy('nomor','ASC')->get();
        $data = Menu::all();
        return view('menu',compact('data','menu'));
    }

    public function savemenu(Request $request)
    {
        $this->validate($request, [
            'nomor' => 'required',
            ]);

        $data = new Menu();
            $data->nomor = $_POST['nomor'];
            $data->title = $_POST['title'];
            $data->menu = $_POST['menu'];
            $data->submenu = $_POST['submenu'];
            $data->link = $_POST['link'];
            $data->icon = $_POST['icon'];
            $data->sub = $_POST['sub'];
        $data->save();
        Session::flash('sukses', 'Data berhasil di simpan');
        return back();
    }

    public function updatemenu($id)
    {
        $data = Menu::find($id);
            $data->nomor = $_POST['nomor'];
            $data->title = $_POST['title'];
            $data->menu = $_POST['menu'];
            $data->submenu = $_POST['submenu'];
            $data->link = $_POST['link'];
            $data->icon = $_POST['icon'];
            $data->sub = $_POST['sub'];
        $data->update();
        Session::flash('sukses', 'Data berhasil di edit');
        return back();
    }

    public function deletemenu($id)
    {
        $data = Menu::find($id);
        $data->delete();
        Session::flash('sessionhapus', 'Data berhasil di hapus');
        return back();
    }
}
