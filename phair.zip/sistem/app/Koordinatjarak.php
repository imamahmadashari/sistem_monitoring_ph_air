<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Koordinatjarak extends Model
{
    protected $table = 'tb_koordinat_jarak';
        protected $fillable = [
    'nilai_p',
    'koordinat',
    'jarak_titik_1',
    'jarak_titik_2',
    'jarak_titik_3'
    ];
}
