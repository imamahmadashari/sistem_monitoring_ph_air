<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Koordinat extends Model
{
    protected $table = 'tb_koordinat';
        protected $fillable = [
    'lat','lon'
    ];
}
