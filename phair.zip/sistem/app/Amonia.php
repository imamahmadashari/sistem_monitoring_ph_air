<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Phair extends Model
{
    protected $table = 'tb_phair';
    protected $fillable = [
    ];	
}
