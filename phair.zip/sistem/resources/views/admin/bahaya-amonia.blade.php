@extends('layouts.app-admin')
@section('content')
<section id="main-content">
  <section class="wrapper">
    <h3><i class="fa fa-angle-right"></i> INDIKATOR BAHAYA PH AIR</h3>
    <div class="content-panel">
      <div class="row">
        <div class="col-lg-12">
          <div class="panel panel-primary">
            <div class="panel panel-heading">
              <button class="btn btn-default">INDIKATOR BAHAYA PH AIR</button>
            </div>
            <div class="panel panel-body">
              <div class="row">
                <div class="col-md-12">
                  <section class="table table-responsive">
                    <table id="example1" class="table table-responsive table-bordered table-hover table-striped">
                      <thead>
                        <tr>
                          <th class="text-center">No</th>
                          <th class="text-center">pH Air</th>
                          <th class="text-center">Efek Bahaya</th>
                          <th class="text-center">Sumber</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $no = 1; ?>
                        @foreach($data as $row)
                        <tr>
                          <td align="center">{{$no}}</td>
                          <td align="center">{{$row->ppm}}</td>
                          <td>{{$row->efek}}</td>
                          <td>{{$row->sumber}}</td>
                        </tr>
                        <?php $no++; ?>
                        @endforeach
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</section>
<script type="text/javascript" src="{{ asset('js/bootstrap.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/jquery-1.11.1.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/jquery.dataTables.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/dataTables.bootstrap.js') }}"></script>
<script type="text/javascript">
  $(function() {
    $('#example1').dataTable();
  });
</script>
@endsection
