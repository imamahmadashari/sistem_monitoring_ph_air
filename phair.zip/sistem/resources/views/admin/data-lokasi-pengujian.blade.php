@extends('layouts.app-admin')
@section('content')
<script type="text/javascript">
  // setTimeout(function(){   window.location.reload(1); }, 5000);
</script>
<section id="main-content">
  <section class="wrapper">
    <h3><i class="fa fa-angle-right"></i> DATA LOKASI PENGUJIAN</h3>
    <div class="content-panel">
      <div class="row">
        <div class="col-lg-12">
          <div class="panel panel-primary">
            <div class="panel panel-heading">
              <button class="btn btn-default"><strong>DATA LOKASI PENGUJIAN</strong>
            </b>
            </div>
            <div class="panel panel-body">
              <div class="row">
                <div class="col-md-12">
                  <section class="table table-responsive">
                    <table id="example1" class="table table-responsive table-bordered table-hover table-striped">
                      <thead>
                        <tr>
                          <th class="text-center">No</th>
                          <th class="text-center">Titik Koordinat</th>
                          <th class="text-center">Jarak dengan titik 1</th>
                          <th class="text-center">Jarak dengan titik 2</th>
                          <th class="text-center">Jarak dengan titik 3</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $no = 1; ?>
                        @foreach($data as $row)
                        <tr>
                          <td align="center">{{$no}}</td>
                          <td align="center">{{$row->koordinat}}</td>
                          <td align="center">{{$row->jarak_titik_1}}</td>
                          <td align="center">{{$row->jarak_titik_2}}</td>
                          <td align="center">{{$row->jarak_titik_3}}</td>
                        </tr>
                        <?php $no++; ?>
                        @endforeach
                      </tbody>
                    </table>
                  </section>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</section>
<script type="text/javascript" src="{{ asset('js/bootstrap.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/jquery-1.11.1.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/jquery.dataTables.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/dataTables.bootstrap.js') }}"></script>
<script type="text/javascript">
  $(function() {
    $('#example1').dataTable();
  });
</script>
@endsection
