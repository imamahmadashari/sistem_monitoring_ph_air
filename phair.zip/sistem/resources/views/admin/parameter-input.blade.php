@extends('layouts.app-admin')
@extends('layouts.alert')
@section('content')
<section id="main-content">
  <section class="wrapper">
    <h3><i class="fa fa-angle-right"></i> PARAMETER INPUT</h3>
    <div class="row mt">
      <div class="col-lg-12">
        <div class="form-panel">
          <div class="form-horizontal style-form">
            @foreach($data as $row)
            {!! Form::model($row, ['url' => ['/update-parameter-input', $row->id]]) !!}
            <div class="form-group">
              <div class="row">
                <div class="col-md-12">
              <label class="control-label col-md-2">Nilai P</label>
              <div class="col-md-4">
                <div class="input-group bootstrap-timepicker">
                  <input type="text" class="form-control timepicker-default" value="{{$row->nilai_p}}" name="nilai_p"><br>
                </div>
              </div>
            </div>
          </div>
            <div class="row">
              <div class="col-md-12">
              <label class="control-label col-md-2">Time Series</label>
              <div class="col-md-4">
                <div class="input-group bootstrap-timepicker">
                  <input type="text" class="form-control timepicker-default" value="{{$row->time_series}}" name="timeseries">
                  <span class="input-group-btn">
                    <button class="btn btn-theme03" type="button"><i class="fa fa-clock-o"></i></button>
                  </span>
                </div>
                <br><button class="btn btn-theme02"><i class="fa fa-save"></i> Ubah</button>
                <br><br><div class="alert alert-warning">* Time Series digunakan untuk memasukan rentang waktu berapa lama kadar amonia akan dihitung dan kemudian ditampilkan</div>
              </div>
            </div>
            </div>
          </div>
          {!!Form::close()!!}
          @endforeach
        </div>
      </div>
      </div>
    </div>
  </section>
</section>
@endsection
