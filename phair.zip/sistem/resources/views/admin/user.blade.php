@extends('layouts.app-admin')
@extends('layouts.alert')
@section('content')
<section id="main-content">
  <section class="wrapper">
    <h3><i class="fa fa-angle-right"></i> DATA USER</h3>
    <div class="content-panel">
      <div class="row">
        <div class="col-lg-12">
          <div class="panel panel-primary">
            <div class="panel panel-heading">
              <button class="btn btn-default" data-toggle="modal" data-target="#myModal">
                <i class="fa fa-plus"></i> Tambah User
              </button>
            </div>
            <div class="panel panel-body">
              <div class="row">
                <div class="col-md-12">
                  <section class="table table-responsive">
                    <table id="example1" class="table table-responsive table-bordered table-hover table-striped">
                      <thead>
                        <tr>
                          <th class="text-center">No</th>
                          <th class="text-center">Nama</th>
                          <th class="text-center">Email</th>
                          <th class="text-center">Username</th>
                          <th class="text-center">View Password</th>
                          <th class="text-center">Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $no = 1; ?>
                        @foreach($data as $row)
                        <tr>
                          <td align="center">{{$no}}</td>
                          <td>{{$row->name}}</td>
                          <td>{{$row->email}}</td>
                          <td>{{$row->username}}</td>
                          <td>{{$row->lihat_password}}</td>
                          <td align="center">
                            <button class="btn btn-primary btn-xs" title="Edit" data-toggle="modal" data-target="#yourModal1{{$row->id}}"> <i class="fa fa-edit"></i> Edit</button>
                            <a href="{!! url('/'.$row->id.'/hapus-user') !!}">
                              <button class="btn btn-danger btn-xs"><i class="fa fa-trash"></i> Hapus</button>
                            </a>
                          </td>
                        </tr>
                        <?php $no++; ?>
                        @endforeach
                      </tbody>
                    </table>
                  </section>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</section>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Tambah User</h4>
      </div>
      <div class="modal-body">
        {!! Form::open(['files'=>true, 'url' => ['/simpan-user']]) !!}
        {{ csrf_field() }}

        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
          <label for="name" class="col-md-4 control-label">Foto</label>
          <div class="col-md-8">
            <input type="file" name="foto" class="form-control">
          </div>
        </div><br><br><br>

        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
          <label for="name" class="col-md-4 control-label">Name</label>

          <div class="col-md-8">
            <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" required autofocus>

            @if ($errors->has('name'))
            <span class="help-block">
              <strong>{{ $errors->first('name') }}</strong>
            </span>
            @endif
          </div>
        </div><br><br><br>
        <div class="form-group{{ $errors->has('username') ? ' has-error' : '' }}">
          <label for="username" class="col-md-4 control-label">Username</label>

          <div class="col-md-8">
            <input id="username" type="text" class="form-control" name="username" value="{{ old('username') }}" required autofocus>

            @if ($errors->has('username'))
            <span class="help-block">
              <strong>{{ $errors->first('username') }}</strong>
            </span>
            @endif
          </div>
        </div><br><br>

        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
          <label for="email" class="col-md-4 control-label">E-Mail Address</label>

          <div class="col-md-8">
            <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required>

            @if ($errors->has('email'))
            <span class="help-block">
              <strong>{{ $errors->first('email') }}</strong>
            </span>
            @endif
          </div>
        </div><br><br>

        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
          <label for="password" class="col-md-4 control-label">Password</label>

          <div class="col-md-8">
            <input id="password" type="password" class="form-control" name="password" required>

            @if ($errors->has('password'))
            <span class="help-block">
              <strong>{{ $errors->first('password') }}</strong>
            </span>
            @endif
          </div>
        </div><br><br>
        <div class="form-group">
          <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>
          <div class="col-md-8">
            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
          </div>
        </div><br><br>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button class="btn btn-primary">Simpan</button>
      </div>
      {{Form::close()}}
    </div>
  </div>
</div>
</div>
@foreach ($data as $row)    
{!! Form::model($row, ['url' => ['/update-user', $row->id]]) !!}
<div class="modal fade" id="yourModal1{{$row->id}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Edit User</h4>
      </div>
      <div class="modal-body">
        Nama Lengkap:
        <input type="text" name="name" value="{{$row->name}}" class="form-control"><br>
        Username:
        <input type="text" name="username" value="{{$row->username}}" class="form-control"><br>
        Email:
        <input type="text" name="email" value="{{$row->email}}" class="form-control"><br>
        Password:
        <input type="text" name="password" class="form-control"><br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button class="btn btn-primary">Update</button>
      </div>
    </div>
  </div>
</div>
</div>
{!!Form::close()!!}
@endforeach
<script type="text/javascript" src="{{ asset('js/bootstrap.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/jquery-1.11.1.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/jquery.dataTables.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/dataTables.bootstrap.js') }}"></script>
<script type="text/javascript">
  $(function() {
    $('#example1').dataTable();
  });
</script>
@endsection
