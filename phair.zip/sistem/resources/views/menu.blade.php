@extends('layouts.alert')
@extends('layouts.app-admin')
@section('content')
<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Dashboard</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Menu</a></li>
                    <li class="active">Manage Menu</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="col-md-9">
                            <strong class="card-title">Data Menu</strong>
                        </div>
                        <div class="col-md-3">
                            <button class="btn btn-primary btn-block" data-toggle="modal" data-target="#yourModal"><i class="fa fa-plus"></i> Tambah Menu</button>
                        </div>
                    </div>
                    <div class="card-body">
                      <table id="bootstrap-data-table" class="table table-striped table-bordered">
                        <thead>
                          <tr>
                            <th>Nomor</th>
                            <th>Title</th>
                            <th>Menu</th>
                            <th>Submenu</th>
                            <th>Link</th>
                            <th>Icon</th>
                            <th>Sub</th>
                            <th width="20%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($data as $row)
                        <tr>
                            <td>{{$row->nomor}}</td>
                            <td>{{$row->title}}</td>
                            <td>{{$row->menu}}</td>
                            <td>{{$row->submenu}}</td>
                            <td>{{$row->link}}</td>
                            <td>{{$row->icon}}</td>
                            <td>{{$row->sub}}</td>
                            <td>
                                <button class="btn btn-primary btn-xs tooltipku" data-toggle="modal" data-target="#yourModal1{{$row->id}}"> <i class="fa fa-edit"></i> Edit</button> 
                                <a href="{{url('/'.$row->id.'/delete-menu')}}">
                                <button class="btn btn-danger btn-xs"><i class="fa fa-trash"></i> Hapus</button>
                                </a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
<!-- Tambah --> 
{!! Form::open(['url' => 'save-menu']) !!}
<div class="modal fade" id="yourModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
          Tambah Menu
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-6">
            Nomor:
            <input type="number" name="nomor" class="form-control"><br>
        </div>
        <div class="col-md-6">
            Title:
            <input type="text" name="title" class="form-control"><br>
        </div>
    </div>
    <div class="row">
    <div class="col-md-6">
            Menu:
            <input type="text" name="menu" class="form-control"><br>
        </div>
      <div class="col-md-6">
        Sub Menu:
        <input type="text" name="submenu" class="form-control"><br>
    </div>
</div>
<div class="row">
<div class="col-md-6">
        Link:
        <input type="text" name="link" class="form-control"><br>
    </div>
  <div class="col-md-6">
    Icon:
    <input type="text" name="icon" class="form-control"><br>
</div>
<div class="col-md-6">
        Sub:
        <input type="number" name="sub" class="form-control"><br>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    <button class="btn btn-primary">Simpan</button>
</div>
</div>
</div>
</div>
</div>
</div>
{!!Form::close()!!}
<!--  -->

<!-- Edit -->
@foreach ($data as $row)    
{!! Form::model($row, ['url' => ['/update-menu', $row->id]]) !!}
<div class="modal fade" id="yourModal1{{$row->id}}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
          Edit Menu
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-md-6">
            Nomor:
            <input type="number" name="nomor" value="{{$row->nomor}}" class="form-control"><br>
        </div>
        <div class="col-md-6">
            Title:
            <input type="text" name="title" value="{{$row->title}}" class="form-control"><br>
        </div>
    </div>
    <div class="row">
    <div class="col-md-6">
            Menu:
            <input type="text" name="menu" value="{{$row->menu}}" class="form-control"><br>
        </div>
      <div class="col-md-6">
        Sub Menu:
        <input type="text" name="submenu" value="{{$row->submenu}}" class="form-control"><br>
    </div>
    
</div>
<div class="row">
<div class="col-md-6">
        Link:
        <input type="text" name="link" value="{{$row->link}}" class="form-control"><br>
    </div>
  <div class="col-md-6">
    Icon:
    <input type="text" name="icon" value="{{$row->icon}}" class="form-control"><br>
</div>
</div>
<div class="row">
<div class="col-md-6">
        Sub:
        <input type="number" name="sub" value="{{$row->sub}}" class="form-control"><br>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    <button class="btn btn-primary">Update</button>
</div>
</div>
</div>
</div>
</div>
</div>
{!!Form::close()!!}
@endforeach
<!--  -->
<script type="text/javascript">
    $(document).ready(function() {
      $('#bootstrap-data-table-export').DataTable();
  } );
</script>
@endsection
