<?php

return [

    /*
    |---------------------------------------------------------------------------------------
    | Baris Bahasa untuk Penomoran Halaman
    |---------------------------------------------------------------------------------------
    |
    | Baris bahasa berikut digunakan oleh pustaka penomoran untuk membuat
    | tautan yang sederhana. Anda bebas untuk mengubahnya keapa pun yang Anda
    | inginkan menyesuaikan dengan pandangan Anda agar lebih cocok ke aplikasi Anda.
    |
    */

    'previous' => '&laquo; Sebelumnya',
    'next'     => 'Berikutnya &raquo;',

];
