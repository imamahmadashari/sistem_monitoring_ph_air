<?php

Route::get('/', 'HomeController@index');

// -------------------------------------------------------------------------------------
Auth::routes();
Route::get('/home', 'AdminController@index')->name('home');
Route::get('/data-phair', 'AdminController@dataphair');
Route::get('/data-notifikasi', 'AdminController@datanotifikasi');
Route::get('/data-lokasi-pengujian', 'AdminController@datalokasipengujian');
Route::get('/bahaya-amonia', 'AdminController@bahayaamonia');
Route::get('/user', 'AdminController@user');
Route::post('/simpan-user', 'AdminController@simpanuser');
Route::post('/update-user/{id}', 'AdminController@updateuser');
Route::get('{id}/hapus-user', 'AdminController@hapususer');
Route::get('/parameter-input', 'AdminController@parameterinput');
Route::post('/update-parameter-input/{id}', 'AdminController@updateparameterinput');
Route::post('/update-inputan', 'AdminController@updateinputan');
Route::get('/edukasi', 'AdminController@edukasi');

//Realtime Simulasi
Route::get('/simulasi-save-realtime-amonia-aman', 'AdminController@simulasiaman');
Route::get('/simulasi-save-realtime-amonia-waspada', 'AdminController@simulasiwaspada');
Route::get('/simulasi-save-realtime-amonia-bahaya', 'AdminController@simulasibahaya');

