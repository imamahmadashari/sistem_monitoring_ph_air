<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>HOME - SISTEM INFORMASI MONITORING PH - AIR</title>
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="<?php echo e(asset('lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/zabuto_calendar.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/gritter/css/jquery.gritter.css')); ?>" />
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/style-responsive.css')); ?>" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/modules/export-data.js"></script>
</head>

<body>
  <section id="container">
    <header class="header black-bg">
      <a href="<?php echo e(url('/')); ?>" class="logo"><b>SIPHAIR</b></a>
      <div class="nav notify-row" id="top_menu">
        <ul class="nav top-menu">
          <li id="header_inbox_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle">
              <i class="fa fa-warning" title="Waspada"></i>
              <span class="badge bg-warning">
                <?php
                  $notif = DB::select('select count(id) as jumlah from tb_notifikasi_bahaya');
                  $jumlah = $notif[0]->jumlah; 
                  echo "" . $jumlah;
                ?>
              </span>
            </a>
          </li>
        </ul>
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="auth" href="<?php echo e(url('/login')); ?>"><i class="fa fa-sign-in"></i> Login</a></li>
        </ul>
      </div>
    </header>
  <section class="wrapper">
    <div class="row">
      <div class="col-lg-8 main-chart">
        <div class="border-head">
          <h2><i class="fa fa-bar-chart-o"></i> GRAFIK MONITORING PH AIR</h2>
          <h6>Hasil Pemantauan pH air sumur menggunakan peralatan IoT (Internet of Things) sensor pH air dan metode IDW (Inverse Distance Weighting) untuk menaksir nilai pH air</h6><hr>
        </div>
        <div id="koordinatChart"></div>
        <script>
          document.addEventListener('DOMContentLoaded', function () {
            var output_koordinat = <?php echo $output_koordinat; ?>;
            var output_phair = <?php echo $output_phair; ?>;

    // Membentuk data dalam format yang sesuai dengan Highcharts
            var data = output_koordinat.map(function (koordinat, index) {
              var latLng = koordinat.split(',');
    var nilai_phair = output_phair[index]; // Mengambil nilai_phair yang sesuai
    var color, shape;

    if (nilai_phair < 6.5) {
      color = 'red';
      shape = 'square';
    } else if (nilai_phair > 8.5) {
      color = 'purple';
      shape = 'square';
    } else {
      color = 'blue';
      shape = 'circle';
    }

    return {
      x: parseFloat(latLng[0]),
      y: parseFloat(latLng[1]),
      nilai_phair: nilai_phair,
      color: color,
      marker: {
            symbol: shape // Menggunakan bentuk yang telah ditentukan
          }
        };
      });

            Highcharts.chart('koordinatChart', {
              chart: {
                type: 'scatter',
                zoomType: 'xy'
              },
              title: {
                text: 'Sebaran Titik Koordinat'
              },
              xAxis: {
                title: {
                  enabled: true,
                  text: 'Koordinat X'
                },
                startOnTick: true,
                endOnTick: true,
                showLastLabel: true
              },
              yAxis: {
                title: {
                  text: 'Koordinat Y'
                }
              },
              tooltip: {
                formatter: function () {
                  return 'Lat: ' + this.point.x + '<br>Long: ' + this.point.y + '<br>Estimasi pH: ' + this.point.nilai_phair;
                }
              },
              series: [{
                name: 'Koordinat',
                data: data,
                colorByPoint: true
              }]
            });
          });
        </script>
        <div class="row mt">
          <div class="col-md-4 col-sm-4 mb">
            <div class="grey-panel pn" style="height: 100%;">
              <div class="grey-header">
                <h5>TITIK 1</h5>
              </div>
              <div id="grafik1"></div>
              <script type="text/javascript">
                $(function () { 
                  var data_ph = <?php echo $ph1; ?>;
                  var data_waktu = <?php echo $waktu1; ?>;
                  $('#grafik1').highcharts({
                    chart: {
                      type: 'line'
                    },
                    title: {
                      text: 'GARFIK PERUBAHAN pH AIR DI TITIK 1'
                    },
                    xAxis: {
                      categories: data_waktu
                    },
                    yAxis: {
                      title: {
                        text: 'ph'
                      },
                    },
                    plotOptions: {
                      line: {
                        dataLabels: {
                          enabled: true
                        },
                        enableMouseTracking: false
                      },
                    },
                    series: [{
                      name: 'ph',
                      data: data_ph
                    }]
                  });
                });
              </script>
              <p class="mt"><b>Tinggi pH air di sumur 1</b><br>satuan pH</p>
            </div>
          </div>
          <div class="col-md-4 col-sm-4 mb">
            <div class="grey-panel pn" style="height: 100%;">
              <div class="grey-header">
               <h5>TITIK 2 (Sumur</h5>
             </div>
             <div id="grafik2"></div>
             <script type="text/javascript">
              $(function () { 
                var data_ph = <?php echo $ph2; ?>;
                var data_waktu = <?php echo $waktu2; ?>;
                $('#grafik2').highcharts({
                  chart: {
                    type: 'line'
                  },
                  title: {
                    text: 'GARFIK PERUBAHAN pH Air DI TITIK 2'
                  },
                  xAxis: {
                    categories: data_waktu
                  },
                  yAxis: {
                    title: {
                      text: 'ph'
                    },
                  },
                  plotOptions: {
                    line: {
                      dataLabels: {
                        enabled: true
                      },
                      enableMouseTracking: false
                    },
                  },
                  series: [{
                    name: 'ph',
                    data: data_ph
                  }]
                });
              });
            </script>
            <p class="mt"><b>Tinggi pH air di sumur 2</b><br>satuan pH</p>
          </div>
        </div>
        <div class="col-md-4 col-sm-4 mb">
          <div class="grey-panel pn" style="height: 100%;">
            <div class="grey-header">
             <h5>TITIK 3</h5>
           </div>
           <div id="grafik3"></div>
           <script type="text/javascript">
            $(function () { 
              var data_ph = <?php echo $ph3; ?>;
              var data_waktu = <?php echo $waktu3; ?>;
              $('#grafik3').highcharts({
                chart: {
                  type: 'line'
                },
                title: {
                  text: 'GARFIK PERUBAHAN pH Air DI TITIK 3'
                },
                xAxis: {
                  categories: data_waktu
                },
                yAxis: {
                  title: {
                    text: 'ph'
                  },
                },
                plotOptions: {
                  line: {
                    dataLabels: {
                      enabled: true
                    },
                    enableMouseTracking: false
                  },
                },
                series: [{
                  name: 'ph',
                  data: data_ph
                }]
              });
            });
          </script>
          <p class="mt"><b>Tinggi pH air di sumur 3</b><br>satuan pH</p>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-4 ds">
    <div class="main">
      <h4><center>HITUNG METODE INVERSE DISTANCE WEIGHT</center></h4><hr>
      <div class="row">
        <div class="col-md-6">
          <span><strong>JUMLAH TITIK</strong></span>
          <input type="text" class="form-control" value="3" disabled="disabled"><br>
        </div>
      </div>
      <?php echo Form::open(['url' => 'update-inputan']); ?>

      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-7">
          <span><strong>*TIME SERIES</strong></span>
          <input type="text" name="timeseries" disabled class="form-control" value="<?php echo e($time); ?>"><br>
        </div>
        <div class="col-md-5">
          <span><strong>NILAI P</strong></span>
          <input type="text" class="form-control" disabled name="nilai_p" value="<?php echo e($nilai_p); ?>"><br>
        </div>
      </div>
      <!-- <div class="row">
        <div class="col-md-12">
          <button class="btn btn-primary btn-block"><i class="fa fa-save"></i> SIMPAN</button>
        </div>
      </div><br> -->
      <?php echo Form::close(); ?>

    </div>
    <div class="row">
      <div class="col-md-12 mb">
        <div class="white-panel pn" style="height: 80%;">
          <div class="white-header">
            <h5>NOTIFIKASI pH Air</h5>
          </div>
          <section class="table table-responsive" style="font-size: 10px;">
            <table id="example1" class="table table-responsive table-hover table-striped">
              <thead>
                <tr>
                  <th class="text-center">No</th>
                  <th class="text-center">Waktu</th>
                  <th class="text-center">pH</th>
                  <th class="text-center">Koordinat</th>
                </tr>
              </thead>
              <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $notifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($row->ph <= 6.5): ?>
                <tr style="background-color: red; color: white;">
                  <?php elseif($row->ph >= 8.5): ?>
                  <tr style="background-color: purple; color: white;">
                    <?php endif; ?>
                    <td align="center"><?php echo e($no); ?></td>
                    <td align="center"><?php echo e($row->waktu); ?></td>
                    <td align="center"><?php echo e($row->ph); ?></td>
                    <td align="center"><?php echo e($row->koordinat); ?></td>
                  </tr>
                  <?php $no++; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </section>
          </div>
        </div>
      </div>
    </div>
    <section class="wrapper">
      <div class="row">
        <div class="col-md-12 mb">
          <div class="message-p pn" style="height: 100%; background-color: white;">
            <div class="message-header">
              <h5>KETERANGAN</h5>
            </div>
            <div class="row">
              <div class="col-md-12">
                <ul align="justify" style="padding:10px;">
                  <li><span class="badge bg-info">1</span> Pengambilan data dilakukan di 3 (tiga) titik menggunakan sensor</li><p></p>
                  <li><span class="badge bg-warning">2</span> Kadar pH air dihitung selama <?php echo e($time); ?> menit sekali </li><p></p>
                  <li><span class="badge bg-success">3</span> Kadar pH air ditampilkan dalam rentang waktu 8 jam terakhir</li><p></p>
                  <li><span class="badge bg-danger">4</span> Ketika pH air dalam kondisi tidak normal (Terlalu Asam < 6.5 s/d 8.5 > Terlalu Basa) maka notifikasi akan ditampilkan pada dashboard sistem<p></p>
                    <li><span class="badge bg-primary">5</span> Kadar pH air sumur yang di taksir kadar pH nya adalah air sumur yang ada di 1 RT, yaitu Rt.02, Rw. 03, Desa Wanarejan Utara </li><p></p>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/dataTables.bootstrap.js')); ?>"></script>
        <script type="text/javascript">
          $(function() {
            $('#example1').dataTable();
          });
        </script>
    <footer class="site-footer">
      <div class="text-center">
        <p>
          By. Imam Ahmad Ashari
        </p>
        <div class="credits">Monitoring Kadar pH Air Sumur di Desa Home Industri Sarung Goyor Pemalang dengan Teknologi IoT dan Metode Inverse Distance Weight
        </div>
        <a href="index.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
        </a>
      </div>
    </footer>
  </section>
  <!-- <script src="<?php echo e(asset('lib/jquery/jquery.min.js')); ?>"></script> -->
  <script src="<?php echo e(asset('lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script class="include" type="text/javascript" src="<?php echo e(asset('lib/jquery.dcjqaccordion.2.7.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.scrollTo.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('lib/jquery.sparkline.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/common-scripts.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('lib/gritter/js/jquery.gritter.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('lib/gritter-conf.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/sparkline-chart.js')); ?>"></script>
</body>
</html>
