<?php $__env->startSection('content'); ?>
<section id="main-content">
  <section class="wrapper">
    <div class="row">
      <div class="col-lg-9 main-chart">
        <div class="border-head">
          <h2><i class="fa fa-bar-chart-o"></i> Ammonia Rate</h2>
          <h6>Hasil perhitungan kadar amonia di lingkungan peternakan menggunakan metode Inverse Distance Weight (IDW)</h6><hr>
        </div>

        <div class="row">
          <div class="col-md-12">
            <div id="grafik"></div>

            <!--  -->
            <script type="text/javascript">
              $(function () { 
                var data_hasil = <?php echo $hasil; ?>;
                var data_waktu = <?php echo $waktu; ?>;
                $('#grafik').highcharts({
                  chart: {
                    zoomType: 'x'
                  },
                  title: {
                    text: 'GARFIK PERUBAHAN AMONIA'
                  },
                  xAxis: {
                    categories: data_waktu
                  },
                  yAxis: {
                    title: {
                      text: 'ppm'
                    },
                  },
                  legend: {
                    enabled: false
                  },
                  plotOptions: {
                    area: {
                      fillColor: {
                        linearGradient: {
                          x1: 0,
                          y1: 0,
                          x2: 0,
                          y2: 1
                        },
                        stops: [
                        [0, Highcharts.getOptions().colors[0]],
                        [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                        ]
                      },
                      marker: {
                        radius: 2
                      },
                      lineWidth: 1,
                      states: {
                        hover: {
                          lineWidth: 1
                        }
                      },
                      threshold: null
                    }
                  },

                  series: [{
                    type: 'area',
                    name: 'ppm',
                    data: data_hasil
                  }]
                });
              });
            </script>
          </div>
        </div>
        <div class="row mt">
          <div class="col-md-4 col-sm-4 mb">
            <div class="grey-panel pn" style="height: 100%;">
              <div class="grey-header">
                <h5>TITIK U (Angin Masuk Kandang)</h5>
              </div>
              <div id="grafik1"></div>
              <script type="text/javascript">
                $(function () { 
                  var data_ppm = <?php echo $ppm1; ?>;
                  var data_waktu = <?php echo $waktu1; ?>;
                  $('#grafik1').highcharts({
                    chart: {
                      type: 'line'
                    },
                    title: {
                      text: 'GARFIK PERUBAHAN AMONIA DI TITIK 1'
                    },
                    xAxis: {
                      categories: data_waktu
                    },
                    yAxis: {
                      title: {
                        text: 'ppm'
                      },
                    },
                    plotOptions: {
                      line: {
                        dataLabels: {
                          enabled: true
                        },
                        enableMouseTracking: false
                      },
                    },
                    series: [{
                      name: 'ppm',
                      data: data_ppm
                    }]
                  });
                });
              </script>
              <p class="mt"><b>Sebaran emisi gas amonia di luar kandang sebelum angin melewati kandang </b><br>Satuan PPM (Part Per Million)</p>
            </div>
          </div>
          <div class="col-md-4 col-sm-4 mb">
            <div class="grey-panel pn" style="height: 100%;">
              <div class="grey-header">
                <h5>TITIK K (Dalam Kandang)</h5>
              </div>
              <div id="grafik2"></div>
              <script type="text/javascript">
                $(function () { 
                  var data_ppm = <?php echo $ppm2; ?>;
                  var data_waktu = <?php echo $waktu2; ?>;
                  $('#grafik2').highcharts({
                    chart: {
                      type: 'line'
                    },
                    title: {
                      text: 'GARFIK PERUBAHAN AMONIA DI TITIK 2'
                    },
                    xAxis: {
                      categories: data_waktu
                    },
                    yAxis: {
                      title: {
                        text: 'ppm'
                      },
                    },
                    plotOptions: {
                      line: {
                        dataLabels: {
                          enabled: true
                        },
                        enableMouseTracking: false
                      },
                    },
                    series: [{
                      name: 'ppm',
                      data: data_ppm
                    }]
                  });
                });
              </script>
              <p class="mt"><b>Sebaran emisi gas amonia di dalam kandang</b><br>Satuan PPM (Part Per Million)</p>
            </div>
          </div>
          <div class="col-md-4 col-sm-4 mb">
            <div class="grey-panel pn" style="height: 100%;">
              <div class="grey-header">
                <h5>TITIK D (Angin Keluar Kandang)</h5>
              </div>
              <div id="grafik3"></div>
              <script type="text/javascript">
                $(function () { 
                  var data_ppm = <?php echo $ppm3; ?>;
                  var data_waktu = <?php echo $waktu3; ?>;
                  $('#grafik3').highcharts({
                    chart: {
                      type: 'line'
                    },
                    title: {
                      text: 'GARFIK PERUBAHAN AMONIA DI TITIK 3'
                    },
                    xAxis: {
                      categories: data_waktu
                    },
                    yAxis: {
                      title: {
                        text: 'ppm'
                      },
                    },
                    plotOptions: {
                      line: {
                        dataLabels: {
                          enabled: true
                        },
                        enableMouseTracking: false
                      },
                    },
                    series: [{
                      name: 'ppm',
                      data: data_ppm
                    }]
                  });
                });
              </script>
              <p class="mt"><b>Sebaran emisi gas amonia titik di luar kandang setelah angin melewati kandang</b><br>Satuan PPM (Part Per Million)</p>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 ds">
        <div class="main">
          <h4><center>HITUNG METODE INVERSE DISTANCE WEIGHT</center></h4><hr>
          <div class="row">
          <div class="col-md-6">
            <span><strong>JUMLAH TITIK</strong></span>
            <input type="text" class="form-control" value="3" disabled="disabled"><br>
          </div>
          
        </div>
         <?php echo Form::open(['url' => 'update-inputan']); ?>

        <?php echo e(csrf_field()); ?>

        <div class="row">
          <div class="col-md-7">
            <span><strong>*TIME SERIES (Menit)</strong></span>
            <input type="text" name="timeseries" class="form-control" value="<?php echo e($time); ?>"><br>
          </div>
          <div class="col-md-5">
            <span><strong>NILAI P</strong></span>
            <input type="text" class="form-control" value="3" value="<?php echo e($nilai_p); ?>"><br>
          </div>
        </div>
        </div>
        <div class="row">
          <div class="col-md-12 mb">
            <div class="weather-2 pn">
              <div class="weather-2-header">
                <div class="row">
                  <div class="col-md-12">
                    <center><h5>INPUT INVERSE DISTANCE <br>(Meter)</h5></center>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-8 col-md-offset-2">
                  <div class="input-group input-large">
                      <span class="input-group-addon">*id U</span>
                      <input type="number" class="form-control dpd2" name="idu" value="<?php echo e($jarak_u); ?>">
                    </div><br>
                </div>
              </div>
              <div class="row">
                <div class="col-md-8 col-md-offset-2">
                  <div class="input-group input-large">
                      <span class="input-group-addon">*id K</span>
                      <input type="number" class="form-control dpd2" name="idk" value="<?php echo e($jarak_k); ?>">
                    </div><br>
                </div>
              </div>
              <div class="row">
                <div class="col-md-8 col-md-offset-2">
                  <div class="input-group input-large">
                      <span class="input-group-addon">*id D</span>
                      <input type="number" class="form-control dpd2" name="idd" value="<?php echo e($jarak_d); ?>">
                    </div><br>
                </div>
              </div>
              <div class="row">
                <div class="col-md-8 col-md-offset-2">
                  <button class="btn btn-primary btn-block"><i class="fa fa-save"></i> SIMPAN</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php echo Form::close(); ?>

        <div class="row">
          <div class="col-md-12 mb">
            <div class="white-panel pn" style="height: 100%;">
              <div class="white-header">
                <h5>NOTIFIKASI AMONIA</h5>
              </div>
              <section class="table table-responsive" style="font-size: 10px;">
                <table id="example1" class="table table-responsive table-hover table-striped">
                  <thead>
                    <tr>
                      <th class="text-center">No</th>
                      <th class="text-center">Waktu</th>
                      <th class="text-center">Kadar Amonia (ppm)</th>
                      <th class="text-center">Level Bahaya</th>
                      <th class="text-center">Indikator Bahaya</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $no = 1; ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td align="center"><?php echo e($no); ?></td>
                      <td align="center"><?php echo e($row->waktu); ?></td>
                      <td align="right"><?php echo e($row->ppm); ?></td>
                      <td align="center"><?php if($row->ppm < 5): ?> <span class="badge bg-info" style="font-size: 10px;">aman</span><?php elseif($row->ppm > 5 and $row->ppm < 20): ?> <span class="badge bg-warning" style="font-size: 10px;">waspada</span> <?php elseif($row->ppm > 20): ?> <span class="badge bg-danger" style="font-size: 10px;">bahaya</span> <?php endif; ?></td>
                      <td align="right"></td>
                      <td align="right"></td>
                    </tr>
                    <?php $no++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </section>
            </div>
          </div>
        </div><br>
        <div class="row">
          <div class="col-md-12 mb">
            <div class="message-p pn" style="height: 100%;">
              <div class="message-header">
                <h5>KETERANGAN</h5>
              </div>
              <div class="row">
                <div class="col-md-11" align="justify">
                  <ul>
                    <li><span class="badge bg-info">1</span> Pengambilan data dilakukan di 3 (tiga) titik menggunakan sensor, yaitu luar kandang arah angin masuk (U), dalam kandang (K) dan luar kandang arah angin keluar (D) </li><br>
                    <li><span class="badge bg-warning">2</span> Kadar amonia di kandang dihitung selama <?php echo e($time); ?> menit sekali </li><br>
                    <li><span class="badge bg-success">3</span> Kadar amonia ditampilkan selama 8 jam </li><br>
                    <li><span class="badge bg-danger">4</span> Ketika kadar amonia dalam kondisi waspada dan bahaya notifikasi akan dikirim langsung lewat smartphone yang sudah terinstal aplikasi simonia </li><br>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/dataTables.bootstrap.js')); ?>"></script>
    <script type="text/javascript">
      $(function() {
        $('#example1').dataTable();
      });
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>