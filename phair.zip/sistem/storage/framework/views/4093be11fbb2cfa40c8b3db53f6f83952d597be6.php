<?php $__env->startSection('content'); ?>
<section id="main-content">
  <section class="wrapper">
    <h3><i class="fa fa-angle-right"></i> EDUKASI</h3>
    <div class="row mt">
      <div class="col-lg-12">
        <div class="form-panel">
          <div class="form-horizontal style-form">
            <div class="row">
              <div class="col-lg-12">
            <div class="col-md-4">
              <div class="btn btn-compose">pH Air</div>
              <img src="<?php echo e(asset('/images/sistem/ph-icon-5.jpg')); ?>" width="100%">
            </div>
            <div class="col-md-8">
              <ul>
                <li><label class="label label-info"><i class="fa fa-angle-double-right"></i></label> Standar pH air minum sumur yang aman untuk dikonsumsi berada antara 6,5 dan 8,5 (WHO, 2011) <br><br></li>
                <li><label class="label label-warning"><i class="fa fa-angle-double-right"></i></label> Kualitas air sumur dapat dipengaruhi oleh perubahan musim dan faktor lainnya (Kabir dkk., 2021) <br><br> </li>
                <li><label class="label label-danger"><i class="fa fa-angle-double-right"></i></label> pH air berkapur memiliki kadar pH > 8. Derajat Keasaman (pH) netral air tanah yang baik memiliki pH berkisar 6.5 s/d 7.5. Air tanah yang terlalu asam berbahaya untuk di minum manusia, bahkan hewan peliharaan/ ternak(Widyastuti dkk., 2022) <br></li>
              </ul>
            </div>
          </div>
        </div>
        </div>
      </div>
      </div>
      <div class="col-lg-12">
        <div class="form-panel">
          <div class="form-horizontal style-form">
            <div class="row">
              <div class="col-lg-12">
            <div class="col-md-4">
              <div class="btn btn-compose">Metode Inverse Distance Weight (IDW)</div>
              <img src="<?php echo e(asset('/images/sistem/idw.png')); ?>" width="100%">
            </div>
            <div class="col-md-8">
              <p>Metode Inverse Distance Weighting (IDW) adalah sebuah teknik dalam analisis spasial yang digunakan untuk memperkirakan nilai di lokasi tertentu berdasarkan nilai yang ada di sekitarnya. Metode ini umumnya digunakan dalam pemetaan, interpolasi data, dan analisis geostatistik.</p>

    <p>Dalam metode IDW, terdapat beberapa komponen penting, termasuk simbol-simbol yang Anda sebutkan:</p>

    <ul>
        <li><strong>U:</strong> Simbol ini mewakili nilai yang ingin diestimasi (unknown value) pada suatu lokasi tertentu di dalam suatu grid atau peta. Metode IDW akan memberikan perkiraan nilai U berdasarkan nilai yang ada di sekitarnya.</li>
        <li><strong>K:</strong> K adalah parameter yang disebut dengan "power parameter" atau "exponent parameter". Nilai K mengontrol sejauh mana pengaruh nilai-nilai yang lebih jauh dari lokasi estimasi terhadap perhitungan. Jika nilai K semakin besar, maka pengaruh nilai-nilai yang jauh dari lokasi estimasi akan lebih kecil. Sebaliknya, jika nilai K semakin kecil, pengaruh nilai-nilai yang jauh akan lebih besar.</li>
        <li><strong>D:</strong> Dalam konteks metode IDW, D mengacu pada jarak antara lokasi estimasi (tempat U akan dihitung) dan lokasi data yang diketahui nilainya. Jarak ini dapat diukur dalam unit apapun yang sesuai dengan jenis data dan analisis yang dilakukan.</li>
        <li><strong>P:</strong> Pada umumnya, P merupakan parameter yang menentukan jenis metrik jarak yang digunakan. P dapat bernilai beragam, seperti 1 (jika menggunakan metrik jarak Manhattan) atau 2 (jika menggunakan metrik jarak Euclidean). Nilai P akan mempengaruhi perhitungan jarak antara lokasi estimasi dan lokasi data yang diketahui nilai-nilainya.</li>
    </ul>

    <p>Dalam rumus IDW, nilai U dihitung dengan memperhitungkan sejumlah nilai terdekat dari lokasi estimasi dengan bobot berdasarkan jarak. Rumus IDW dapat ditulis sebagai berikut:</p>

    <p>
        <img src="<?php echo e(asset('/images/sistem/rumus-idw.png')); ?>" width="15%">
    </p>

    <p>Di mana:</p>
    <ul>
        <li><strong>U</strong> adalah nilai yang diestimasi.</li>
        <li><strong>n</strong> adalah jumlah titik data yang diketahui.</li>
        <li><strong>D<sub>i</sub></strong> adalah jarak antara lokasi estimasi dan titik data ke-i.</li>
        <li><strong>Z<sub>i</sub></strong> adalah nilai data pada titik ke-i.</li>
        <li><strong>p</strong> adalah parameter eksponen.</li>
        <li>Rumus menggunakan penjumlahan dari semua titik data yang diketahui dalam perhitungan.</li>
    </ul>

    <p>Dengan menggunakan parameter K, D, dan P yang tepat, metode IDW dapat memberikan perkiraan nilai yang akurat untuk lokasi yang tidak memiliki data observasi langsung.</p>

            </div>
          </div>
        </div>
        </div>
      </div>
      </div>
    </div>
  </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>