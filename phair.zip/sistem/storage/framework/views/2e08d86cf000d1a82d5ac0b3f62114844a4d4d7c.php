<?php $__env->startSection('content'); ?>
<section id="main-content">
  <section class="wrapper">
    <h3><i class="fa fa-angle-right"></i> INDIKATOR BAHAYA AMONIA</h3>
    <div class="content-panel">
      <div class="row">
        <div class="col-lg-12">
          <div class="panel panel-primary">
            <div class="panel panel-heading">
              <button class="btn btn-default">INDIKATOR BAHAYA AMONIA</button>
            </div>
            <div class="panel panel-body">
              <div class="row">
                <div class="col-md-12">
                  <section class="table table-responsive">
                    <table id="example1" class="table table-responsive table-bordered table-hover table-striped">
                      <thead>
                        <tr>
                          <th class="text-center">No</th>
                          <th class="text-center">PPM</th>
                          <th class="text-center">Efek Bahaya</th>
                          <th class="text-center">Sumber</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td align="center"><?php echo e($no); ?></td>
                          <td align="center"><?php echo e($row->ppm); ?></td>
                          <td><?php echo e($row->efek); ?></td>
                          <td><?php echo e($row->sumber); ?></td>
                        </tr>
                        <?php $no++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</section>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery-1.11.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/dataTables.bootstrap.js')); ?>"></script>
<script type="text/javascript">
  $(function() {
    $('#example1').dataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>