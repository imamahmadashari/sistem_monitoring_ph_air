<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>HOME - SISTEM INFORMASI DETEKSI BAHAYA GAS AMONIA (NH3) PADA LINGKUNGAN PETERNAKAN MENGGUNAKAN METODE INVERSE DISTANCE WEIGHT</title>
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="<?php echo e(asset('lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/zabuto_calendar.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/gritter/css/jquery.gritter.css')); ?>" />
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/style-responsive.css')); ?>" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/modules/export-data.js"></script>
</head>

<body>
  <section id="container">
    <header class="header black-bg">
      <a href="<?php echo e(url('/')); ?>" class="logo"><b>SIMONIA</b></a>
      <div class="nav notify-row" id="top_menu">
        <ul class="nav top-menu">
          <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-thumbs-o-up" title="Aman"></i>
              <span class="badge bg-info">5</span>
            </a>
            <ul class="dropdown-menu extended tasks-bar">
              <div class="notify-arrow notify-arrow-green"></div>
              <li>
                <p class="green">5 Data terakhir amonia dalam kondisi aman</p>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">06:00:00 <strong style="float: right;">1.25%</strong></div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">06:15:00 <strong style="float: right;">1.00%</strong></div>
                  </div>
                </a>
              </li>
              <li class="external">
                <a href="#">Lihat Selengkapnya >></a>
              </li>
            </ul>
          </li>
          <li id="header_inbox_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-warning" title="Waspada"></i>
              <span class="badge bg-warning">5</span>
            </a>
            <ul class="dropdown-menu extended tasks-bar">
              <div class="notify-arrow notify-arrow-yellow"></div>
              <li>
                <p class="yellow">5 Data terakhir amonia dalam kondisi waspada</p>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-warning">
                    <div class="desc">01:00:00 <strong style="float: right;">8.25%</strong></div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-warning">
                    <div class="desc">01:15:00 <strong style="float: right;">8.00%</strong></div>
                  </div>
                </a>
              </li>
              <li class="external">
                <a href="#">Lihat Selengkapnya >></a>
              </li>
            </ul>
          </li>
          <li id="header_notification_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-ambulance" title="Bahaya"></i>
              <span class="badge bg-danger">5</span>
            </a>
            <ul class="dropdown-menu extended tasks-bar">
              <div class="notify-arrow notify-arrow-red"></div>
              <li>
                <p class="red">5 Data terakhir amonia dalam kondisi bahaya</p>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-danger">
                    <div class="desc">02:00:00 <strong style="float: right;">21.25%</strong></div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-danger">
                    <div class="desc">02:15:00 <strong style="float: right;">22.00%</strong></div>
                  </div>
                </a>
              </li>
              <li class="external">
                <a href="#">Lihat Selengkapnya >></a>
              </li>
            </ul>
          </li>
        </ul>
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="auth" href="<?php echo e(url('/login')); ?>"><i class="fa fa-sign-in"></i> Login</a></li>
        </ul>
      </div>
    </header>
    <section id="main">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-9 main-chart">
            <div class="border-head">
              <h2><i class="fa fa-bar-chart-o"></i> Ammonia Rate</h2>
              <h6>Hasil perhitungan kadar amonia di lingkungan peternakan menggunakan metode Inverse Distance Weight (IDW)</h6><hr>
            </div>
            
            <div class="row">
              <div class="col-md-12">
                <div id="grafik"></div>

                <!--  -->
                <script type="text/javascript">
                  $(function () { 
                    var data_ppm = <?php echo $ppm; ?>;
                    var data_waktu = <?php echo $waktu; ?>;
                    $('#grafik').highcharts({
                      chart: {
                        zoomType: 'x'
                      },
                      title: {
                        text: 'GARFIK PERUBAHAN AMONIA'
                      },
                      xAxis: {
                        categories: data_waktu
                      },
                      yAxis: {
                        title: {
                          text: 'ppm'
                        },
                      },
                      legend: {
                        enabled: false
                      },
                      plotOptions: {
                        area: {
                          fillColor: {
                            linearGradient: {
                              x1: 0,
                              y1: 0,
                              x2: 0,
                              y2: 1
                            },
                            stops: [
                            [0, Highcharts.getOptions().colors[0]],
                            [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                            ]
                          },
                          marker: {
                            radius: 2
                          },
                          lineWidth: 1,
                          states: {
                            hover: {
                              lineWidth: 1
                            }
                          },
                          threshold: null
                        }
                      },

                      series: [{
                        type: 'area',
                        name: 'ppm',
                        data: data_ppm
                      }]
                    });
                  });
                </script>
              </div>
            </div>
            <div class="row mt">
              <div class="col-md-4 col-sm-4 mb">
                <div class="grey-panel pn">
                  <div class="grey-header">
                    <h5>TITIK U (Angin Masuk Kandang)</h5>
                  </div>
                  <div id="grafik1"></div>
                  <script type="text/javascript">
                    $(function () { 
                      var data_ppm = <?php echo $ppm1; ?>;
                      var data_waktu = <?php echo $waktu1; ?>;
                      $('#grafik1').highcharts({
                        chart: {
                          type: 'line'
                        },
                        title: {
                          text: 'GARFIK PERUBAHAN AMONIA DI TITIK 1'
                        },
                        xAxis: {
                          categories: data_waktu
                        },
                        yAxis: {
                          title: {
                            text: 'ppm'
                          },
                        },
                        plotOptions: {
                          line: {
                            dataLabels: {
                              enabled: true
                            },
                            enableMouseTracking: false
                          },
                        },
                        series: [{
                          name: 'ppm',
                          data: data_ppm
                        }]
                      });
                    });
                  </script>
                  <p class="mt"><b>Sebaran emisi gas amonia di luar kandang sebelum angin melewati kandang </b><br>Satuan PPM (Part Per Million)</p>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 mb">
                <div class="grey-panel pn">
                  <div class="grey-header">
                    <h5>TITIK K (Dalam Kandang)</h5>
                  </div>
                  <div id="grafik2"></div>
                  <script type="text/javascript">
                    $(function () { 
                      var data_ppm = <?php echo $ppm2; ?>;
                      var data_waktu = <?php echo $waktu2; ?>;
                      $('#grafik2').highcharts({
                        chart: {
                          type: 'line'
                        },
                        title: {
                          text: 'GARFIK PERUBAHAN AMONIA DI TITIK 2'
                        },
                        xAxis: {
                          categories: data_waktu
                        },
                        yAxis: {
                          title: {
                            text: 'ppm'
                          },
                        },
                        plotOptions: {
                          line: {
                            dataLabels: {
                              enabled: true
                            },
                            enableMouseTracking: false
                          },
                        },
                        series: [{
                          name: 'ppm',
                          data: data_ppm
                        }]
                      });
                    });
                  </script>
                  <p class="mt"><b>Sebaran emisi gas amonia di dalam kandang</b><br>Satuan PPM (Part Per Million)</p>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 mb">
                <div class="grey-panel pn">
                  <div class="grey-header">
                    <h5>TITIK D (Angin Keluar Kandang)</h5>
                  </div>
                  <div id="grafik3"></div>
                  <script type="text/javascript">
                    $(function () { 
                      var data_ppm = <?php echo $ppm3; ?>;
                      var data_waktu = <?php echo $waktu3; ?>;
                      $('#grafik3').highcharts({
                        chart: {
                          type: 'line'
                        },
                        title: {
                          text: 'GARFIK PERUBAHAN AMONIA DI TITIK 3'
                        },
                        xAxis: {
                          categories: data_waktu
                        },
                        yAxis: {
                          title: {
                            text: 'ppm'
                          },
                        },
                        plotOptions: {
                          line: {
                            dataLabels: {
                              enabled: true
                            },
                            enableMouseTracking: false
                          },
                        },
                        series: [{
                          name: 'ppm',
                          data: data_ppm
                        }]
                      });
                    });
                  </script>
                  <p class="mt"><b>Sebaran emisi gas amonia titik di luar kandang setelah angin melewati kandang</b><br>Satuan PPM (Part Per Million)</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 ds">
            <div class="main">
              <h4><center>BOBOT ANTARA TITIK SAMPLE</center></h4><hr>
              <span><strong>INPUT JUMLAH TITIK</strong></span>
              <select class="form-control" name="titik" disabled="disabled">
                <option>3</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
              </select><br>
            </div>
            <div class="row">
              <div class="col-md-12 mb">
                <div class="weather-2 pn">
                  <div class="weather-2-header">
                    <div class="row">
                      <div class="col-md-12">
                        <center><h5>INPUT</h5></center>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                      <span><strong>*Range Titik U</strong></span>
                      <input type="text" name="titiku" class="form-control" value="100" disabled="disabled">
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                      <span><strong>*Range Titik K</strong></span>
                      <input type="text" name="titikk" class="form-control" value="5" disabled="disabled">
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                      <span><strong>*Range Titik D</strong></span>
                      <input type="text" name="titikd" class="form-control" value="200" disabled="disabled">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 mb">
                <div class="white-panel pn">
                  <div class="white-header">
                    <h5>NOTIFIKASI AMONIA</h5>
                  </div>
                  <section class="table table-responsive" style="font-size: 10px;">
                    <table class="table table-responsive table-hover table-striped">
                      <thead>
                        <tr>
                          <th class="text-center">No</th>
                          <th class="text-center">Waktu</th>
                          <th class="text-center">Kadar Amonia (ppm)</th>
                          <th class="text-center">Level Bahaya</th>
                          <th class="text-center">Indikator Bahaya</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td align="center"><?php echo e($no); ?></td>
                          <td align="center"><?php echo e($row->waktu); ?></td>
                          <td align="right"><?php echo e($row->ppm); ?></td>
                          <td align="center"><?php if($row->ppm < 5): ?> <span class="badge bg-info" style="font-size: 10px;">aman</span><?php elseif($row->ppm > 5 and $row->ppm < 20): ?> <span class="badge bg-warning" style="font-size: 10px;">waspada</span> <?php elseif($row->ppm > 20): ?> <span class="badge bg-danger" style="font-size: 10px;">bahaya</span> <?php endif; ?></td>
                          <td align="right"></td>
                          <td align="right"></td>
                        </tr>
                        <?php $no++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </section>
                </div>
              </div>
            </div><br>
            <div class="row">
              <div class="col-md-12 mb">
                <div class="message-p pn" style="height: 400px;">
                  <div class="message-header">
                    <h5>KETERANGAN</h5>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <ul>
                        <li><span class="badge bg-info">1</span> Pengambilan data dilakukan di 3 (tiga) titik menggunakan sensor, yaitu luar kandang arah angin masuk (U), dalam kandang (K) dan luar kandang arah angin keluar (D) </li><br>
                        <li><span class="badge bg-warning">2</span> Kadar amonia di kandang dihitung selama <?php echo e($time); ?> menit sekali </li><br>
                        <li><span class="badge bg-success">3</span> Kadar amonia ditampilkan selama 8 jam </li><br>
                        <li><span class="badge bg-danger">4</span> Ketika kadar amonia dalam kondisi waspada dan bahaya notifikasi akan dikirim langsung lewat smartphone yang sudah terinstal aplikasi simonia </li><br>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </section>
    <footer class="site-footer">
      <div class="text-center">
        <p>
          By. Imam Ahmad Ashari
        </p>
        <div class="credits">Tesis Magister Sistem Informasi (UNDIP)
        </div>
        <a href="index.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
        </a>
      </div>
    </footer>
  </section>
  <!-- <script src="<?php echo e(asset('lib/jquery/jquery.min.js')); ?>"></script> -->
  <script src="<?php echo e(asset('lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script class="include" type="text/javascript" src="<?php echo e(asset('lib/jquery.dcjqaccordion.2.7.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.scrollTo.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('lib/jquery.sparkline.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/common-scripts.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('lib/gritter/js/jquery.gritter.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('lib/gritter-conf.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/sparkline-chart.js')); ?>"></script>
</body>
</html>
