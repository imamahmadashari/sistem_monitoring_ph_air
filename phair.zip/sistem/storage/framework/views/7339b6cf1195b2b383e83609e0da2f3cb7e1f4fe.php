<?php $__env->startSection('content'); ?>
<section id="main-content">
  <section class="wrapper">
    <h3><i class="fa fa-angle-right"></i> PARAMETER INPUT</h3>
    <div class="row mt">
      <div class="col-lg-12">
        <div class="form-panel">
          <div class="form-horizontal style-form">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo Form::model($row, ['url' => ['/update-parameter-input', $row->id]]); ?>

            <div class="form-group">
              <div class="row">
                <div class="col-md-12">
              <label class="control-label col-md-2">Nilai P</label>
              <div class="col-md-4">
                <div class="input-group bootstrap-timepicker">
                  <input type="text" class="form-control timepicker-default" value="<?php echo e($row->nilai_p); ?>" name="nilai_p"><br>
                </div>
              </div>
            </div>
          </div>
            <div class="row">
              <div class="col-md-12">
              <label class="control-label col-md-2">Time Series</label>
              <div class="col-md-4">
                <div class="input-group bootstrap-timepicker">
                  <input type="text" class="form-control timepicker-default" value="<?php echo e($row->time_series); ?>" name="timeseries">
                  <span class="input-group-btn">
                    <button class="btn btn-theme03" type="button"><i class="fa fa-clock-o"></i></button>
                  </span>
                </div>
                <br><button class="btn btn-theme02"><i class="fa fa-save"></i> Ubah</button>
                <br><br><div class="alert alert-warning">* Time Series digunakan untuk memasukan rentang waktu berapa lama kadar amonia akan dihitung dan kemudian ditampilkan</div>
              </div>
            </div>
            </div>
          </div>
          <?php echo Form::close(); ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      </div>
    </div>
  </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>