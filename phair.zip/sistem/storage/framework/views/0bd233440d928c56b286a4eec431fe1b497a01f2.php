<?php $__env->startSection('content'); ?>
<section id="main-content">
  <section class="wrapper">
    <div class="row">
      <div class="col-lg-9 main-chart">
        <div class="border-head">
          <h2><i class="fa fa-bar-chart-o"></i> WATER PH MONITORING CHART</h2>
          <h6>Results of monitoring the pH of well water using IoT (Internet of Things) water pH sensor equipment and the IDW (Inverse Distance Weighting) method to estimate the pH value of water</h6><hr>
        </div>
        <div id="koordinatChart"></div>
        <script>
          document.addEventListener('DOMContentLoaded', function () {
            var output_koordinat = <?php echo $output_koordinat; ?>;
            var output_phair = <?php echo $output_phair; ?>;

    // Membentuk data dalam format yang sesuai dengan Highcharts
            var data = output_koordinat.map(function (koordinat, index) {
              var latLng = koordinat.split(',');
    var nilai_phair = output_phair[index]; // Mengambil nilai_phair yang sesuai
    var color, shape;

    if (nilai_phair < 6.5) {
      color = 'red';
      shape = 'square';
    } else if (nilai_phair > 8.5) {
      color = 'purple';
      shape = 'square';
    } else {
      color = 'blue';
      shape = 'circle';
    }

    return {
      x: parseFloat(latLng[0]),
      y: parseFloat(latLng[1]),
      nilai_phair: nilai_phair,
      color: color,
      marker: {
            symbol: shape // Menggunakan bentuk yang telah ditentukan
          }
        };
      });

            Highcharts.chart('koordinatChart', {
              chart: {
                type: 'scatter',
                zoomType: 'xy'
              },
              title: {
                text: 'Distribution of Coordinate Points'
              },
              xAxis: {
                title: {
                  enabled: true,
                  text: 'Coordinate X'
                },
                startOnTick: true,
                endOnTick: true,
                showLastLabel: true
              },
              yAxis: {
                title: {
                  text: 'Coordinate Y'
                }
              },
              tooltip: {
                formatter: function () {
                  return 'Lat: ' + this.point.x + '<br>Long: ' + this.point.y + '<br>pH estimation: ' + this.point.nilai_phair;
                }
              },
              series: [{
                name: 'Coordinate',
                data: data,
                colorByPoint: true
              }]
            });
          });
        </script>
        <div class="row mt">
          <div class="col-md-4 col-sm-4 mb">
            <div class="grey-panel pn" style="height: 100%;">
              <div class="grey-header">
                <h5>POINT 1</h5>
              </div>
              <div id="grafik1"></div>
              <script type="text/javascript">
                $(function () { 
                  var data_ph = <?php echo $ph1; ?>;
                  var data_waktu = <?php echo $waktu1; ?>;
                  $('#grafik1').highcharts({
                    chart: {
                      type: 'line'
                    },
                    title: {
                      text: 'Graph of Changes in Water pH at Point 1'
                    },
                    xAxis: {
                      categories: data_waktu
                    },
                    yAxis: {
                      title: {
                        text: 'ph'
                      },
                    },
                    plotOptions: {
                      line: {
                        dataLabels: {
                          enabled: true
                        },
                        enableMouseTracking: false
                      },
                    },
                    series: [{
                      name: 'ph',
                      data: data_ph
                    }]
                  });
                });
              </script>
              <p class="mt"><b>High pH of the water in the well 1</b><br>pH unit</p>
            </div>
          </div>
          <div class="col-md-4 col-sm-4 mb">
            <div class="grey-panel pn" style="height: 100%;">
              <div class="grey-header">
               <h5>POINT 2</h5>
             </div>
             <div id="grafik2"></div>
             <script type="text/javascript">
              $(function () { 
                var data_ph = <?php echo $ph2; ?>;
                var data_waktu = <?php echo $waktu2; ?>;
                $('#grafik2').highcharts({
                  chart: {
                    type: 'line'
                  },
                  title: {
                    text: 'Graph of Changes in Water pH at Point 2'
                  },
                  xAxis: {
                    categories: data_waktu
                  },
                  yAxis: {
                    title: {
                      text: 'ph'
                    },
                  },
                  plotOptions: {
                    line: {
                      dataLabels: {
                        enabled: true
                      },
                      enableMouseTracking: false
                    },
                  },
                  series: [{
                    name: 'ph',
                    data: data_ph
                  }]
                });
              });
            </script>
            <p class="mt"><b>High pH of the water in the well 2</b><br>pH unit</p>
          </div>
        </div>
        <div class="col-md-4 col-sm-4 mb">
          <div class="grey-panel pn" style="height: 100%;">
            <div class="grey-header">
             <h5>POINT 3</h5>
           </div>
           <div id="grafik3"></div>
           <script type="text/javascript">
            $(function () { 
              var data_ph = <?php echo $ph3; ?>;
              var data_waktu = <?php echo $waktu3; ?>;
              $('#grafik3').highcharts({
                chart: {
                  type: 'line'
                },
                title: {
                  text: 'Graph of Changes in Water pH at Point 3'
                },
                xAxis: {
                  categories: data_waktu
                },
                yAxis: {
                  title: {
                    text: 'ph'
                  },
                },
                plotOptions: {
                  line: {
                    dataLabels: {
                      enabled: true
                    },
                    enableMouseTracking: false
                  },
                },
                series: [{
                  name: 'ph',
                  data: data_ph
                }]
              });
            });
          </script>
          <p class="mt"><b>High pH of the water in the well 3</b><br>pH unit</p>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-3 ds">
    <div class="main">
      <h4><center>CALCULATE INVERSE DISTANCE WEIGHT METHOD</center></h4><hr>
      <div class="row">
        <div class="col-md-6">
          <span><strong>NUMBER OF POINTS</strong></span>
          <input type="text" class="form-control" value="3" disabled="disabled"><br>
        </div>
      </div>
      <?php echo Form::open(['url' => 'update-inputan']); ?>

      <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-md-7">
          <span><strong>*TIME SERIES</strong></span>
          <input type="text" name="timeseries" class="form-control" value="<?php echo e($time); ?>"><br>
        </div>
        <div class="col-md-5">
          <span><strong>P VALUE</strong></span>
          <input type="text" class="form-control" name="nilai_p" value="<?php echo e($nilai_p); ?>"><br>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <button class="btn btn-primary btn-block"><i class="fa fa-save"></i> SAVE</button>
        </div>
      </div><br>
      <?php echo Form::close(); ?>

    </div>
    <div class="row">
      <div class="col-md-12 mb">
        <div class="white-panel pn" style="height: 80%;">
          <div class="white-header">
            <h5>Water pH NOTIFICATION</h5>
          </div>
          <section class="table table-responsive" style="font-size: 10px;">
            <table id="example1" class="table table-responsive table-hover table-striped">
              <thead>
                <tr>
                  <th class="text-center">No</th>
                    <th class="text-center">Time</th>
                    <th class="text-center">pH</th>
                    <th class="text-center">Coordinates</th>
                </tr>
              </thead>
              <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $notifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($row->ph <= 6.5): ?>
                <tr style="background-color: red; color: white;">
                  <?php elseif($row->ph >= 8.5): ?>
                  <tr style="background-color: purple; color: white;">
                    <?php endif; ?>
                    <td align="center"><?php echo e($no); ?></td>
                    <td align="center"><?php echo e($row->waktu); ?></td>
                    <td align="center"><?php echo e($row->ph); ?></td>
                    <td align="center"><?php echo e($row->koordinat); ?></td>
                  </tr>
                  <?php $no++; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </section>
          </div>
        </div>
      </div>
    </div>
    <section class="wrapper">
      <div class="row">
        <div class="col-md-12 mb">
          <div class="message-p pn" style="height: 100%; background-color: white;">
            <div class="message-header">
              <h5>Information</h5>
            </div>
            <div class="row">
              <div class="col-md-12">
                <ul align="justify" style="padding:10px;">
                  <li><span class="badge bg-info">1</span> Data collection is carried out at 3 (three) points using sensors</li><p></p>
                  <li><span class="badge bg-warning">2</span> The pH level of the water is calculated every 60 minutes </li><p></p>
                  <li><span class="badge bg-success">3</span> Water pH levels are displayed within the last 8 hours</li><p></p>
                  <li><span class="badge bg-danger">4</span> When the pH of the water is abnormal (Too Acidic < 6.5 to 8.5 > Too Alkaline) then a notification will be displayed on the system dashboard<p></p>
                    <li><span class="badge bg-primary">5</span> The pH level of well water whose pH level is estimated is well water in 1 RT, namely Rt.02, Rw. 03, Wanarejan Utara Village, Pemalang, Jawa Tengah </li><p></p>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/dataTables.bootstrap.js')); ?>"></script>
        <script type="text/javascript">
          $(function() {
            $('#example1').dataTable();
          });
        </script>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>