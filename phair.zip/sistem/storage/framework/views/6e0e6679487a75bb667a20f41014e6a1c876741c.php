<?php $__env->startSection('content'); ?>
<script type="text/javascript">
  // setTimeout(function(){   window.location.reload(1); }, 5000);
</script>
<section id="main-content">
  <section class="wrapper">
    <h3><i class="fa fa-angle-right"></i> DATA AMONIA</h3>
    <div class="content-panel">
      <div class="row">
        <div class="col-lg-12">
          <div class="panel panel-primary">
            <div class="panel panel-heading">
              <button class="btn btn-default"><strong>DATA AMONIA REAL-TIME</strong> || SIMULASI <i class="fa fa-hand-o-right"></i></button>
              <b style="float: right;">
              <a href="<?php echo e(url('simulasi-save-realtime-amonia-aman')); ?>"><button type="button" class="btn btn-round btn-info"><i class="fa fa-refresh"></i> Aman</button></a>
              <a href="<?php echo e(url('simulasi-save-realtime-amonia-waspada')); ?>"><button type="button" class="btn btn-round btn-warning"><i class="fa fa-refresh"></i> Waspada</button></a>
              <a href="<?php echo e(url('simulasi-save-realtime-amonia-bahaya')); ?>"><button type="button" class="btn btn-round btn-danger"><i class="fa fa-refresh"></i> Bahaya</button></a>
            </b>
            </div>
            <div class="panel panel-body">
              <div class="row">
                <div class="col-md-12">
                  <section class="table table-responsive">
                    <table id="example1" class="table table-responsive table-bordered table-hover table-striped">
                      <thead>
                        <tr>
                          <th class="text-center" rowspan="2">No</th>
                          <th class="text-center" rowspan="2">Titik</th>
                          <th class="text-center" rowspan="2">PPM</th>
                          <th class="text-center" rowspan="2">Waktu</th>
                          <th class="text-center" colspan="10">Keterangan</th>
                        </tr>
                        <tr>
                          <th class="text-center">rl</th>
                          <th class="text-center">ro</th>
                          <th class="text-center">vref</th>
                          <th class="text-center">vadc</th>
                          <th class="text-center">resolusi</th>
                          <th class="text-center">adc1</th>
                          <th class="text-center">adc2</th>
                          <th class="text-center">vrl1</th>
                          <th class="text-center">vrl2</th>
                          <th class="text-center">rs</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $no = 1; ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td align="center"><?php echo e($no); ?></td>
                          <td align="center"><?php echo e($row->titik); ?></td>
                          <td align="right"><?php echo e($row->ppm); ?></td>
                          <td align="center"><?php echo e($row->waktu); ?></td>
                          <td align="right"><?php echo e($row->rl); ?></td>
                          <td align="right"><?php echo e($row->ro); ?></td>
                          <td align="right"><?php echo e($row->vref); ?></td>
                          <td align="right"><?php echo e($row->vadc); ?></td>
                          <td align="right"><?php echo e($row->resolusi); ?></td>
                          <td align="right"><?php echo e($row->adc1); ?></td>
                          <td align="right"><?php echo e($row->adc2); ?></td>
                          <td align="right"><?php echo e($row->vrl1); ?></td>
                          <td align="right"><?php echo e($row->vrl2); ?></td>
                          <td align="right"><?php echo e($row->rs); ?></td>
                        </tr>
                        <?php $no++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </section>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</section>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery-1.11.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/dataTables.bootstrap.js')); ?>"></script>
<script type="text/javascript">
  $(function() {
    $('#example1').dataTable();
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>