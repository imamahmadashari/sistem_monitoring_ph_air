<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>HOME - SISTEM INFORMASI MONITORING PH - AIR</title>
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="<?php echo e(asset('lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/zabuto_calendar.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/gritter/css/jquery.gritter.css')); ?>" />
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap.css')); ?>">
  <link href="<?php echo e(asset('css/style-responsive.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('lib/advanced-datatable/css/demo_page.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('lib/advanced-datatable/css/demo_table.css')); ?>" rel="stylesheet" />
  <link rel="stylesheet" href="<?php echo e(asset('lib/advanced-datatable/css/DT_bootstrap.css')); ?>" />
  <link href="<?php echo e(asset('css/table-responsive.css')); ?>" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <style type="text/css">
    .preloader {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 9999;
      background-color: #fff;
    }
    .preloader .loading {
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%,-50%);
      font: 14px arial;
    }
</style>
<script>
    $(document).ready(function(){
      $(".preloader").fadeOut();
    })
    </script>
</head>
<body>

<!--     <div class="preloader">
    <div class="loading">
      <img src="<?php echo e(asset('images/sistem/refresh.gif')); ?>" width="80">
      <p>Harap Tunggu</p>
    </div>
  </div> -->
  <section id="container">
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <a href="<?php echo e(url('home')); ?>" class="logo"><b>SIPHAIR</b></a>
      <div class="nav notify-row" id="top_menu">
        <ul class="nav top-menu">
          <li id="header_inbox_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle">
              <i class="fa fa-warning" title="Waspada"></i>
              <span class="badge bg-warning">
                <?php
                  $notif = DB::select('select count(id) as jumlah from tb_notifikasi_bahaya');
                  $jumlah = $notif[0]->jumlah; 
                  echo "" . $jumlah;
                ?>
              </span>
            </a>
          </li>
        </ul>
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="auth" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
            document.getElementById('logout-form').submit();">
            <i class="fa fa-sign-out"></i> <?php echo e(__('Logout')); ?>

          </a>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
          </form></a></li>
        </ul>
      </div>
    </header>
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('images/sistem/imam.jpg')); ?>" class="img-circle" width="80"></a></p>
          <h5 class="centered">Imam Ahmad Ashari <br></h5>
          <li class="mt">
            <a href="<?php echo e(url('home')); ?>">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('data-phair')); ?>">
              <i class="fa fa-list"></i>
              <span>Data pH Air </span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('data-notifikasi')); ?>">
              <i class="fa fa-list"></i>
              <span>Data Notifikasi </span>
            </a>
          </li>
          <li>
            <a href="<?php echo e(url('data-lokasi-pengujian')); ?>">
              <i class="fa fa-list"></i>
              <span>Data Lokasi Pengujian</span>
            </a>
          </li>
          <!-- <li>
            <a href="<?php echo e(url('bahaya-amonia')); ?>">
              <i class="fa fa-list"></i>
              <span>Indikator Bahaya pH Air</span>
            </a>
          </li> -->
          <li class="sub-menu">
            <a href="javascript:;">
              <i class=" fa fa-gears"></i>
              <span>Manajemen</span>
            </a>
            <ul class="sub">
              <li><a href="<?php echo e(url('user')); ?>">User</a></li>
              <li><a href="<?php echo e(url('parameter-input')); ?>">Parameter Input</a></li>
            </ul>
          </li>
          <li>
            <a href="<?php echo e(url('edukasi')); ?>">
              <i class="fa fa-archive"></i>
              <span>Edukasi </span>
            </a>
          </li>
        </ul>
      </div>
    </aside>
    <?php echo $__env->yieldContent('content'); ?>
    <footer class="site-footer">
      <div class="text-center">
        <p>
          By. Imam Ahmad Ashari
        </p>
        <div class="credits">Monitoring Kadar PH Air Sumur di Desa Home Industri Sarung Goyor Pemalang dengan Teknologi IoT dan Metode Inverse Distance Weight
        </div>
        <a href="<?php echo e(url('/')); ?>" class="go-top">
          <i class="fa fa-angle-up"></i>
        </a>
      </div>
    </footer>
    <script src="<?php echo e(asset('lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script class="include" type="text/javascript" src="<?php echo e(asset('lib/jquery.dcjqaccordion.2.7.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/jquery.scrollTo.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('lib/jquery.sparkline.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/common-scripts.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/gritter/js/jquery.gritter.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/gritter-conf.js')); ?>"></script>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('lib/advanced-datatable/js/jquery.dataTables.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('lib/advanced-datatable/js/DT_bootstrap.js')); ?>"></script>
  </body>
  </html>
