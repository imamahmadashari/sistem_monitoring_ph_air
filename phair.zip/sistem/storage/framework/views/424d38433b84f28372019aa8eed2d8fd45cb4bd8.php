<?php $__env->startSection('content'); ?>
<section id="main-content">
  <section class="wrapper">
    <h3><i class="fa fa-angle-right"></i> EDUKASI</h3>
    <div class="row mt">
      <div class="col-lg-12">
        <div class="form-panel">
          <div class="form-horizontal style-form">
            <div class="row">
              <div class="col-lg-12">
            <div class="col-md-3">
              <div class="btn btn-compose">Amonia (NH3)</div>
              <img src="<?php echo e(asset('/images/sistem/amonia.png')); ?>" width="100%">
            </div>
            <div class="col-md-8">
              <ul>
                <li><label class="label label-info"><i class="fa fa-angle-double-right"></i></label> Peternakan merupakan sumber terbesar penyumbang gas amonia di atmosfer, terdiri dari sekitar 40% dari gabungan emisi alami dan antropogenik (Walker dkk., 2014) <br><br></li>
                <li><label class="label label-warning"><i class="fa fa-angle-double-right"></i></label> Dari kontaminasi di udara, amonia dianggap sebagai gas paling berbahaya yang dilepaskan dari kotoran ayam broiler dan dianggap merugikan bagi rumah unggas modern saat ini (Beker dkk., 2004) <br><br> </li>
                <li><label class="label label-danger"><i class="fa fa-angle-double-right"></i></label> Paling lama manusia boleh terpapar gas amonia dengan kadar 25 ppm adalah selama 8 s/d 10 jam (Ritz dkk., 2016) <br></li>
              </ul>
            </div>
          </div>
        </div>
        </div>
      </div>
      </div>
    </div>
  </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>