-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 25 Agu 2023 pada 04.26
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phair`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `nomor` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `menu` varchar(30) NOT NULL,
  `submenu` varchar(30) NOT NULL,
  `link` varchar(255) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `sub` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `menu`
--

INSERT INTO `menu` (`id`, `nomor`, `title`, `menu`, `submenu`, `link`, `icon`, `sub`, `created_at`, `updated_at`) VALUES
(8, 1, 'UI ELEMENTS', '', '', '', '', 1, '2018-03-18 15:24:20', '2018-03-18 08:24:20'),
(9, 2, '', 'Widgest', '', '{{url(\'/widgest\')}}', 'menu-icon fa fa-book', 2, '2018-03-18 08:25:32', '2018-03-18 08:25:32'),
(10, 3, '', 'Components', '', '', '', 3, '2018-03-18 08:26:33', '2018-03-18 08:26:33'),
(11, 3, '', '', 'Components 1', '', '', 3, '2018-03-18 08:27:17', '2018-03-18 08:27:17');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('imamahmadashari@gmail.com', '$2y$10$6rAZKom0Kps7oeL1YJxOReYiZwdQiOh4c5Gith76dHSPf81m41Pce', '2018-03-16 08:01:48');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_koordinat`
--

CREATE TABLE `tb_koordinat` (
  `id` int(11) NOT NULL,
  `lat` varchar(100) NOT NULL,
  `lon` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tb_koordinat`
--

INSERT INTO `tb_koordinat` (`id`, `lat`, `lon`, `created_at`, `updated_at`) VALUES
(1, '-6.88994', '109.40334', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(2, '-6.88997', '109.40322', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(3, '-6.88987', '109.40304', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(4, '-6.88992', '109.40340', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(5, '-6.89057', '109.40316', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(6, '-6.89024', '109.40343', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(7, '-6.88985', '109.40290', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(8, '-6.89045', '109.40375', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(9, '-6.89015', '109.40305', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(10, '-6.89080', '109.40400', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(11, '-6.89030', '109.40260', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(12, '-6.89060', '109.40335', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(13, '-6.89025', '109.40345', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(14, '-6.89075', '109.40385', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(15, '-6.89095', '109.40320', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(16, '-6.89010', '109.40390', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(17, '-6.89055', '109.40315', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(18, '-6.89040', '109.40360', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(19, '-6.89070', '109.40410', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(20, '-6.89000', '109.40275', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(21, '-6.89090', '109.40405', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(22, '-6.89035', '109.40330', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(23, '-6.89085', '109.40275', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(24, '-6.89005', '109.40295', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(25, '-6.89025', '109.40375', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(26, '-6.89065', '109.40345', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(27, '-6.89015', '109.40270', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(28, '-6.89055', '109.40385', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(29, '-6.89045', '109.40325', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(30, '-6.89085', '109.40355', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(31, '-6.89010', '109.40355', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(32, '-6.89040', '109.40310', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(33, '-6.89070', '109.40390', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(34, '-6.89030', '109.40355', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(35, '-6.89090', '109.40375', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(36, '-6.89020', '109.40395', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(37, '-6.89060', '109.40375', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(38, '-6.89025', '109.40325', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(39, '-6.89075', '109.40315', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(40, '-6.89000', '109.40365', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(41, '-6.89050', '109.40385', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(42, '-6.89080', '109.40330', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(43, '-6.89035', '109.40385', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(44, '-6.89095', '109.40345', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(45, '-6.89010', '109.40325', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(46, '-6.89040', '109.40370', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(47, '-6.89070', '109.40340', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(48, '-6.89030', '109.40375', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(49, '-6.89090', '109.40305', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(50, '-6.89020', '109.40365', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(51, '-6.89060', '109.40305', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(52, '-6.89025', '109.40385', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(53, '-6.89075', '109.40325', '2023-08-07 01:10:27', '2023-08-07 01:10:27'),
(54, '-6.89001', '109.40369', '2023-08-07 01:10:27', '2023-08-07 01:10:27');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_koordinat_jarak`
--

CREATE TABLE `tb_koordinat_jarak` (
  `id` int(11) NOT NULL,
  `nilai_p` int(11) NOT NULL,
  `koordinat` varchar(100) NOT NULL,
  `jarak_titik_1` int(11) NOT NULL,
  `jarak_titik_2` int(11) NOT NULL,
  `jarak_titik_3` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tb_koordinat_jarak`
--

INSERT INTO `tb_koordinat_jarak` (`id`, `nilai_p`, `koordinat`, `jarak_titik_1`, `jarak_titik_2`, `jarak_titik_3`, `created_at`, `updated_at`) VALUES
(1, 3, '-6.88994, 109.40334', 1, 35, 73, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(2, 3, '-6.88997, 109.40322', 14, 38, 67, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(3, 3, '-6.88987, 109.40304', 35, 60, 79, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(4, 3, '-6.88992, 109.4034', 6, 36, 77, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(5, 3, '-6.89057, 109.40316', 73, 47, 0, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(6, 3, '-6.89024, 109.40343', 34, 0, 47, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(7, 3, '-6.88985, 109.4029', 51, 73, 85, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(8, 3, '-6.89045, 109.40375', 72, 42, 66, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(9, 3, '-6.89015, 109.40305', 40, 43, 48, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(10, 3, '-6.8908, 109.404', 119, 89, 96, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(11, 3, '-6.8903, 109.4026', 92, 92, 69, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(12, 3, '-6.8906, 109.40335', 73, 41, 21, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(13, 3, '-6.89025, 109.40345', 36, 2, 48, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(14, 3, '-6.89075, 109.40385', 105, 73, 79, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(15, 3, '-6.89095, 109.4032', 113, 83, 42, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(16, 3, '-6.8901, 109.4039', 63, 54, 97, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(17, 3, '-6.89055, 109.40315', 71, 46, 2, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(18, 3, '-6.8904, 109.4036', 58, 26, 52, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(19, 3, '-6.8907, 109.4041', 118, 90, 105, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(20, 3, '-6.89, 109.40275', 66, 80, 78, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(21, 3, '-6.8909, 109.40405', 131, 100, 105, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(22, 3, '-6.89035, 109.4033', 45, 19, 29, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(23, 3, '-6.89085, 109.40275', 120, 101, 55, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(24, 3, '-6.89005, 109.40295', 45, 57, 62, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(25, 3, '-6.89025, 109.40375', 56, 35, 74, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(26, 3, '-6.89065, 109.40345', 79, 46, 33, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(27, 3, '-6.89015, 109.4027', 75, 81, 69, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(28, 3, '-6.89055, 109.40385', 87, 58, 76, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(29, 3, '-6.89045, 109.40325', 57, 31, 17, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(30, 3, '-6.89085, 109.40355', 103, 69, 53, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(31, 3, '-6.8901, 109.40355', 28, 20, 68, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(32, 3, '-6.8904, 109.4031', 58, 41, 20, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(33, 3, '-6.8907, 109.4039', 104, 73, 83, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(34, 3, '-6.8903, 109.40355', 45, 15, 52, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(35, 3, '-6.8909, 109.40375', 115, 81, 75, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(36, 3, '-6.8902, 109.40395', 72, 58, 96, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(37, 3, '-6.8906, 109.40375', 85, 53, 65, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(38, 3, '-6.89025, 109.40325', 36, 20, 37, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(39, 3, '-6.89075, 109.40315', 92, 65, 20, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(40, 3, '-6.89, 109.40365', 34, 36, 83, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(41, 3, '-6.8905, 109.40385', 83, 55, 77, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(42, 3, '-6.8908, 109.4033', 95, 64, 30, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(43, 3, '-6.89035, 109.40385', 71, 48, 80, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(44, 3, '-6.89095, 109.40345', 112, 79, 53, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(45, 3, '-6.8901, 109.40325', 20, 25, 53, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(46, 3, '-6.8904, 109.4037', 64, 35, 63, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(47, 3, '-6.8907, 109.4034', 84, 51, 30, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(48, 3, '-6.8903, 109.40375', 59, 36, 72, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(49, 3, '-6.8909, 109.40305', 111, 85, 39, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(50, 3, '-6.8902, 109.40365', 44, 25, 68, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(51, 3, '-6.8906, 109.40305', 80, 58, 13, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(52, 3, '-6.89025, 109.40385', 65, 46, 84, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(53, 3, '-6.89075, 109.40325', 90, 60, 22, '2023-08-17 18:43:04', '2023-08-17 18:43:04'),
(54, 3, '-6.89001, 109.40369', 38, 38, 85, '2023-08-17 18:43:04', '2023-08-17 18:43:04');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_notifikasi_bahaya`
--

CREATE TABLE `tb_notifikasi_bahaya` (
  `id` int(11) NOT NULL,
  `koordinat` varchar(255) NOT NULL,
  `ph` float NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tb_notifikasi_bahaya`
--

INSERT INTO `tb_notifikasi_bahaya` (`id`, `koordinat`, `ph`, `waktu`, `created_at`, `updated_at`) VALUES
(1, '-6.88994, 109.40334', 5, '2023-08-17 18:43:04', '2023-08-18 01:43:04', '2023-08-18 01:43:04'),
(2, '-6.88997, 109.40322', 5.21, '2023-08-17 18:43:04', '2023-08-18 01:43:04', '2023-08-18 01:43:04'),
(3, '-6.88987, 109.40304', 5.75, '2023-08-17 18:43:04', '2023-08-18 01:43:04', '2023-08-18 01:43:04'),
(4, '-6.88992, 109.4034', 5.02, '2023-08-17 18:43:04', '2023-08-18 01:43:04', '2023-08-18 01:43:04'),
(5, '-6.89024, 109.40343', 5.55, '2023-08-17 18:43:04', '2023-08-18 01:43:04', '2023-08-18 01:43:04'),
(6, '-6.88985, 109.4029', 6.15, '2023-08-17 18:43:04', '2023-08-18 01:43:04', '2023-08-18 01:43:04'),
(7, '-6.89025, 109.40345', 9, '2023-08-17 18:43:04', '2023-08-18 01:43:04', '2023-08-18 01:43:04'),
(8, '-6.89005, 109.40295', 6.46, '2023-08-17 18:43:04', '2023-08-18 01:43:04', '2023-08-18 01:43:04'),
(9, '-6.8903, 109.40355', 8.82, '2023-08-17 18:43:04', '2023-08-18 01:43:04', '2023-08-18 01:43:04'),
(10, '-6.8901, 109.40325', 6.38, '2023-08-17 18:43:04', '2023-08-18 01:43:04', '2023-08-18 01:43:04');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_parameter_input`
--

CREATE TABLE `tb_parameter_input` (
  `id` int(11) NOT NULL,
  `nilai_p` int(11) NOT NULL,
  `time_series` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tb_parameter_input`
--

INSERT INTO `tb_parameter_input` (`id`, `nilai_p`, `time_series`, `created_at`, `updated_at`) VALUES
(1, 3, 15, '2023-08-05 07:31:04', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_phair`
--

CREATE TABLE `tb_phair` (
  `id` int(11) NOT NULL,
  `vrl` varchar(100) NOT NULL,
  `rs` varchar(100) NOT NULL,
  `ph` float NOT NULL,
  `titik` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tb_phair`
--

INSERT INTO `tb_phair` (`id`, `vrl`, `rs`, `ph`, `titik`, `created_at`, `updated_at`) VALUES
(621, '0.922852', '44179.894531', 5, 1, '2023-08-05 07:56:25', '0000-00-00 00:00:00'),
(622, '0.952148', '42512.820312', 6, 1, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(623, '0.854492', '48514.285156', 6, 1, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(624, '0.917969', '44468.085938', 6, 1, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(625, '0.917969', '44468.085938', 6, 1, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(626, '0.90332', '45351.351562', 6, 1, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(627, '0.908203', '45053.761719', 6, 1, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(628, '0.927734', '43894.738281', 6, 1, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(629, '0.927734', '43894.738281', 6, 1, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(630, '0.90332', '45351.351562', 6, 1, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(631, '0.90332', '45351.351562', 7, 2, '2023-08-03 04:09:06', '0000-00-00 00:00:00'),
(632, '0.922852', '44179.894531', 7, 2, '2023-08-03 04:09:06', '0000-00-00 00:00:00'),
(633, '0.878906', '46888.890625', 7, 2, '2023-08-03 04:09:06', '0000-00-00 00:00:00'),
(634, '0.888672', '46263.734375', 7, 2, '2023-08-03 04:09:06', '0000-00-00 00:00:00'),
(635, '0.927734', '43894.738281', 7, 2, '2023-08-03 04:09:06', '0000-00-00 00:00:00'),
(636, '0.869141', '47528.089844', 7, 2, '2023-08-03 04:09:06', '0000-00-00 00:00:00'),
(637, '0.908203', '45053.761719', 7, 2, '2023-08-03 04:09:06', '0000-00-00 00:00:00'),
(638, '0.913086', '44759.359375', 7, 2, '2023-08-03 04:09:06', '0000-00-00 00:00:00'),
(639, '0.922852', '44179.894531', 7, 2, '2023-08-03 04:09:06', '0000-00-00 00:00:00'),
(640, '0.9375', '43333.332031', 9, 2, '2023-08-05 07:49:00', '0000-00-00 00:00:00'),
(641, '0.976562', '41200', 7, 3, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(642, '0.942383', '43056.996094', 7, 3, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(643, '0.966797', '41717.171875', 7, 3, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(644, '0.957031', '42244.898438', 7, 3, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(645, '0.957031', '42244.898438', 7, 3, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(646, '0.961914', '41979.695312', 7, 3, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(647, '0.952148', '42512.820312', 7, 3, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(648, '0.97168', '41457.285156', 7, 3, '2023-08-05 07:36:58', '0000-00-00 00:00:00'),
(649, '0.961914', '41979.695312', 7, 3, '2023-08-03 04:10:05', '0000-00-00 00:00:00'),
(650, '0.961914', '41979.695312', 7, 3, '2023-08-03 04:10:05', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_phair_validasi`
--

CREATE TABLE `tb_phair_validasi` (
  `id` int(11) NOT NULL,
  `vrl` varchar(100) NOT NULL,
  `rs` varchar(100) NOT NULL,
  `ph` float NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `foto` varchar(200) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `lihat_password` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `foto`, `name`, `email`, `username`, `password`, `remember_token`, `lihat_password`, `created_at`, `updated_at`) VALUES
(10, '', 'Imam Ahmad Ashari', 'imamahmadashari@gmail.com', 'imamahmadashari', '$2y$10$9Z.VOhsIa4TgkdqTfLMHpuTUU9jsdJdy9fnDLL9OCCF86OFvY1.N2', 'USVhIrY9Y7yYAG49hL8IXDIRVKiYYcFKcg182wwDee5VIoL9eL4k2mJUWlrG', '123456', '2018-03-16 21:43:38', '2018-03-16 21:43:38'),
(12, '', 'didik olfaya', 'didik@gmail.com', 'didik', '$2y$10$QB0UgSh44FnozgZWToUa5uBbJ.Yxy9.u1vQcGNOsa.Tc5HVBduqKS', NULL, '12345', '2019-06-20 18:59:45', '2019-06-20 19:06:43'),
(13, 'images/sistem/14643.png', 'zulmi', 'zulmi@gmail.com', 'zulmi', '$2y$10$JibnnBDcpXGPTV6.qRmwIelkn2uwKofekirE5rM7cX3AiZzine45S', NULL, '123456', '2019-06-24 18:47:16', '2019-06-24 18:47:16'),
(14, 'images/sistem/25701.jpg', 'Imam Ahmad Ashari', 'imamahmadashari1@gmail.com', 'imamahmadashari1', '$2y$10$n5NBUwiG46hIgMAzE5.EdeRb6ieOp0fEh077PP5ZxkF1/DV4WwdNa', '2YaGTgRWnFaa0PHYMdr1zE7uYDiZByzp0vOglE6NGx01FoAJDnphDTFIEGPb', '123456', '2019-06-24 18:49:59', '2019-06-24 18:49:59');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_koordinat`
--
ALTER TABLE `tb_koordinat`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_koordinat_jarak`
--
ALTER TABLE `tb_koordinat_jarak`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_notifikasi_bahaya`
--
ALTER TABLE `tb_notifikasi_bahaya`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_parameter_input`
--
ALTER TABLE `tb_parameter_input`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_phair`
--
ALTER TABLE `tb_phair`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_phair_validasi`
--
ALTER TABLE `tb_phair_validasi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tb_koordinat`
--
ALTER TABLE `tb_koordinat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT untuk tabel `tb_koordinat_jarak`
--
ALTER TABLE `tb_koordinat_jarak`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT untuk tabel `tb_notifikasi_bahaya`
--
ALTER TABLE `tb_notifikasi_bahaya`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `tb_parameter_input`
--
ALTER TABLE `tb_parameter_input`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tb_phair`
--
ALTER TABLE `tb_phair`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1181;

--
-- AUTO_INCREMENT untuk tabel `tb_phair_validasi`
--
ALTER TABLE `tb_phair_validasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1181;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
